# -*- coding: utf-8 -*-
"""
DanceMotion-2024 PyTorch DataLoader
====================================
读取COCO格式标注，与论文图3 (网络架构) 输入约定保持一致。

用法:
    from dataset_loader import DanceMotionDataset, build_dataloader

    train_loader = build_dataloader(
        root="/path/to/DanceMotion-2024",
        split="train",
        batch_size=32,
        num_workers=8,
        augmentation_cfg="configs/augmentation.yaml",
    )

    for batch in train_loader:
        imgs, kpts, vis, meta = batch
        # imgs: [B, 3, 384, 384]
        # kpts: [B, 17, 2]   关键点 (x, y) 像素坐标
        # vis : [B, 17]      可见性 0/1/2
        # meta: dict (session_id, dancer_id, category, view, frame_idx)
"""
import os
import json
from typing import Optional, Tuple, Dict, List

import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
from PIL import Image


# COCO 17 关键点定义
KEYPOINTS = [
    "nose", "left_eye", "right_eye", "left_ear", "right_ear",
    "left_shoulder", "right_shoulder",
    "left_elbow", "right_elbow",
    "left_wrist", "right_wrist",
    "left_hip", "right_hip",
    "left_knee", "right_knee",
    "left_ankle", "right_ankle",
]
NUM_KEYPOINTS = 17

# 左右翻转对 (用于水平翻转增强)
FLIP_PAIRS = [
    (1, 2), (3, 4), (5, 6), (7, 8),
    (9, 10), (11, 12), (13, 14), (15, 16),
]


class DanceMotionDataset(Dataset):
    """DanceMotion-2024 数据集 PyTorch 实现.

    参数
    ----
    root : str
        数据集根目录，应包含 frames/ 与 annotations/ 子目录.
    split : str
        "train" / "val" / "test"，对应 annotations/coco/{split}.json.
    image_size : int
        网络输入正方形边长 (默认 384).
    heatmap_size : int
        输出热图边长 (默认 96 = 384/4).
    sigma : float
        高斯热图标准差 (默认 2.0).
    transform : callable, optional
        外部传入的图像增强（如 Albumentations Compose）.
    return_heatmap : bool
        True 时返回热图，否则返回原始坐标. 默认 True.
    category_filter : list[str], optional
        仅加载指定类别，如 ["Ballet", "Modern Dance"].
    """

    def __init__(
        self,
        root: str,
        split: str = "train",
        image_size: int = 384,
        heatmap_size: int = 96,
        sigma: float = 2.0,
        transform=None,
        return_heatmap: bool = True,
        category_filter: Optional[List[str]] = None,
    ):
        assert split in ("train", "val", "test"), f"unknown split: {split}"
        self.root = root
        self.split = split
        self.image_size = image_size
        self.heatmap_size = heatmap_size
        self.sigma = sigma
        self.transform = transform
        self.return_heatmap = return_heatmap
        self.category_filter = set(category_filter) if category_filter else None

        ann_path = os.path.join(root, "annotations", "coco", f"{split}.json")
        with open(ann_path, "r", encoding="utf-8") as f:
            coco = json.load(f)

        # 构建 image_id -> image 字典
        img_lookup = {img["id"]: img for img in coco["images"]}
        self.samples = []
        for ann in coco["annotations"]:
            img = img_lookup.get(ann["image_id"])
            if img is None:
                continue
            if self.category_filter and img.get("dance_category_en") not in self.category_filter:
                continue
            self.samples.append({
                "image_path": os.path.join(root, img["file_name"]),
                "width": img["width"],
                "height": img["height"],
                "session_id": img.get("session_id"),
                "dancer_id": img.get("dancer_id"),
                "category": img.get("dance_category"),
                "view": img.get("camera_view"),
                "frame_index": img.get("frame_index_in_video"),
                "bbox": ann["bbox"],
                "keypoints": np.array(ann["keypoints"], dtype=np.float32).reshape(-1, 3),
            })

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, Dict]:
        s = self.samples[idx]
        img = Image.open(s["image_path"]).convert("RGB")
        img_np = np.array(img)

        # 基于bbox裁剪人体区域
        x, y, w, h = s["bbox"]
        x, y, w, h = int(x), int(y), int(w), int(h)
        # 留 10% 边距
        pad_x = int(0.1 * w)
        pad_y = int(0.1 * h)
        x1 = max(0, x - pad_x)
        y1 = max(0, y - pad_y)
        x2 = min(img_np.shape[1], x + w + pad_x)
        y2 = min(img_np.shape[0], y + h + pad_y)
        crop = img_np[y1:y2, x1:x2]

        kpts = s["keypoints"].copy()
        kpts[:, 0] -= x1
        kpts[:, 1] -= y1

        # 缩放到 image_size × image_size
        ch, cw = crop.shape[:2]
        scale_x = self.image_size / cw
        scale_y = self.image_size / ch
        kpts[:, 0] *= scale_x
        kpts[:, 1] *= scale_y

        crop_img = Image.fromarray(crop).resize(
            (self.image_size, self.image_size), Image.BILINEAR
        )

        if self.transform is not None:
            result = self.transform(image=np.array(crop_img), keypoints=kpts[:, :2].tolist())
            crop_img = Image.fromarray(result["image"])
            kpts[:, :2] = np.array(result["keypoints"], dtype=np.float32)

        # 归一化
        img_tensor = torch.from_numpy(np.array(crop_img)).permute(2, 0, 1).float() / 255.0
        mean = torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1)
        std  = torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)
        img_tensor = (img_tensor - mean) / std

        coords = torch.from_numpy(kpts[:, :2]).float()
        vis    = torch.from_numpy(kpts[:, 2]).long()

        if self.return_heatmap:
            heatmap = self._generate_heatmap(kpts)
            target = torch.from_numpy(heatmap).float()
        else:
            target = coords

        meta = {
            "session_id":  s["session_id"],
            "dancer_id":   s["dancer_id"],
            "category":    s["category"],
            "view":        s["view"],
            "frame_index": s["frame_index"],
        }
        return img_tensor, target, vis, meta

    def _generate_heatmap(self, kpts: np.ndarray) -> np.ndarray:
        """生成17通道高斯热图，对应每个关键点."""
        hm_h = hm_w = self.heatmap_size
        hm = np.zeros((NUM_KEYPOINTS, hm_h, hm_w), dtype=np.float32)
        feat_stride = self.image_size / self.heatmap_size

        for j in range(NUM_KEYPOINTS):
            if kpts[j, 2] < 1:
                continue
            mu_x = kpts[j, 0] / feat_stride
            mu_y = kpts[j, 1] / feat_stride
            if not (0 <= mu_x < hm_w and 0 <= mu_y < hm_h):
                continue
            x = np.arange(hm_w)
            y = np.arange(hm_h)
            xx, yy = np.meshgrid(x, y)
            hm[j] = np.exp(-((xx - mu_x) ** 2 + (yy - mu_y) ** 2) / (2 * self.sigma ** 2))
        return hm


def build_dataloader(
    root: str,
    split: str = "train",
    batch_size: int = 32,
    num_workers: int = 8,
    image_size: int = 384,
    heatmap_size: int = 96,
    shuffle: Optional[bool] = None,
    pin_memory: bool = True,
    augmentation_cfg: Optional[str] = None,
) -> DataLoader:
    """构建 DataLoader. augmentation_cfg 路径用于训练阶段加载增强配置."""
    transform = None
    if split == "train" and augmentation_cfg is not None and os.path.exists(augmentation_cfg):
        # 训练阶段加载增强 (此处仅占位; 实际项目接入 Albumentations Compose)
        try:
            import yaml
            with open(augmentation_cfg, "r", encoding="utf-8") as f:
                _ = yaml.safe_load(f)
            # 用户可在此处根据 yaml 字段实例化 Albumentations.Compose
        except ImportError:
            pass

    ds = DanceMotionDataset(
        root=root, split=split,
        image_size=image_size, heatmap_size=heatmap_size,
        transform=transform,
    )

    if shuffle is None:
        shuffle = (split == "train")

    return DataLoader(
        ds, batch_size=batch_size, num_workers=num_workers,
        shuffle=shuffle, pin_memory=pin_memory, drop_last=(split == "train"),
        collate_fn=_collate_with_meta,
    )


def _collate_with_meta(batch):
    """自定义 collate 函数 — 普通张量按默认方式叠加，meta 字典逐项收集为列表."""
    imgs   = torch.stack([b[0] for b in batch], dim=0)
    target = torch.stack([b[1] for b in batch], dim=0)
    vis    = torch.stack([b[2] for b in batch], dim=0)
    meta_list = [b[3] for b in batch]
    return imgs, target, vis, meta_list


if __name__ == "__main__":
    # 简单自测
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--root", required=True, help="数据集根目录")
    p.add_argument("--split", default="train")
    p.add_argument("--n", type=int, default=3, help="抽样可视化数量")
    args = p.parse_args()

    loader = build_dataloader(args.root, split=args.split, batch_size=args.n, num_workers=0)
    imgs, target, vis, meta = next(iter(loader))
    print(f"imgs:   {imgs.shape}")
    print(f"target: {target.shape}")
    print(f"vis:    {vis.shape}")
    print(f"meta:   {meta}")
