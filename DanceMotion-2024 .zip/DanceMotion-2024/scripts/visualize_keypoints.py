# -*- coding: utf-8 -*-
"""
DanceMotion-2024 关键点可视化工具
=================================
将COCO标注绘制到图像上，支持单帧可视化与批量PDF导出。

用法:
    # 单帧可视化
    python visualize_keypoints.py \
        --annotation annotations/coco/test.json \
        --image_id 42 \
        --output vis_42.png

    # 批量PDF导出 (随机抽20帧)
    python visualize_keypoints.py \
        --annotation annotations/coco/val.json \
        --root /path/to/DanceMotion-2024 \
        --batch_pdf preview.pdf --n 20
"""
import os
import json
import random
import argparse

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from PIL import Image


# COCO 17关键点骨架边 (基于 1-indexed 关键点)
SKELETON_EDGES = [
    (1, 2), (1, 3), (2, 3), (2, 4), (3, 5),                # 头部
    (6, 7), (6, 12), (7, 13), (12, 13),                    # 躯干
    (6, 8), (8, 10),                                       # 左臂
    (7, 9), (9, 11),                                       # 右臂
    (12, 14), (14, 16),                                    # 左腿
    (13, 15), (15, 17),                                    # 右腿
]

# 部位颜色 (IEEE配色)
BODY_PART_COLORS = {
    "head":      "#5d6d7e",
    "torso":     "#1f3a5f",
    "left_arm":  "#d35400",
    "right_arm": "#a93226",
    "left_leg":  "#2e7d32",
    "right_leg": "#117a65",
}

EDGE_PART = {
    (1, 2): "head", (1, 3): "head", (2, 3): "head", (2, 4): "head", (3, 5): "head",
    (6, 7): "torso", (6, 12): "torso", (7, 13): "torso", (12, 13): "torso",
    (6, 8): "left_arm", (8, 10): "left_arm",
    (7, 9): "right_arm", (9, 11): "right_arm",
    (12, 14): "left_leg", (14, 16): "left_leg",
    (13, 15): "right_leg", (15, 17): "right_leg",
}


def draw_keypoints_on_axis(ax, img, kpts, title=None, draw_skeleton=True):
    """在 matplotlib Axes 上绘制图像与关键点骨架.

    kpts: list 或 np.ndarray, 长度 51 (17 个 (x,y,v) 三元组).
    """
    ax.imshow(img)
    kpts = np.array(kpts, dtype=np.float32).reshape(-1, 3)

    if draw_skeleton:
        for (i, j) in SKELETON_EDGES:
            x1, y1, v1 = kpts[i - 1]
            x2, y2, v2 = kpts[j - 1]
            if v1 > 0 and v2 > 0:
                color = BODY_PART_COLORS[EDGE_PART[(i, j)]]
                ax.plot([x1, x2], [y1, y2], color=color, linewidth=2.5, alpha=0.85)

    for idx in range(kpts.shape[0]):
        x, y, v = kpts[idx]
        if v == 2:
            ax.scatter(x, y, s=70, c="#27ae60", edgecolors="white", linewidths=1.5, zorder=4)
        elif v == 1:
            ax.scatter(x, y, s=70, c="#f39c12", edgecolors="white", linewidths=1.5, zorder=4)
        # v == 0 不绘制

    if title:
        ax.set_title(title, fontsize=10)
    ax.axis("off")


def visualize_one(coco_data, image_id, dataset_root, output_path):
    """单帧关键点可视化."""
    img_lookup = {img["id"]: img for img in coco_data["images"]}
    ann_lookup = {}
    for ann in coco_data["annotations"]:
        ann_lookup.setdefault(ann["image_id"], []).append(ann)

    if image_id not in img_lookup:
        raise ValueError(f"image_id {image_id} not found")

    img_meta = img_lookup[image_id]
    img_path = os.path.join(dataset_root, img_meta["file_name"]) if dataset_root else img_meta["file_name"]
    if os.path.exists(img_path):
        img = Image.open(img_path).convert("RGB")
    else:
        # 占位灰底图
        img = Image.new("RGB", (img_meta["width"], img_meta["height"]), (240, 240, 240))

    fig, ax = plt.subplots(figsize=(10, 6), dpi=150)
    for ann in ann_lookup.get(image_id, []):
        title = (f"{img_meta.get('dance_category', '')} / {img_meta.get('combo_id', '')} "
                 f"/ {img_meta.get('camera_view', '')} / 帧 {img_meta.get('frame_index_in_video', '')}")
        draw_keypoints_on_axis(ax, img, ann["keypoints"], title=title)

    plt.tight_layout()
    plt.savefig(output_path, dpi=200, bbox_inches="tight")
    plt.close()
    print(f"已保存: {output_path}")


def batch_to_pdf(coco_data, dataset_root, output_pdf, n_samples=20):
    """批量随机抽样导出PDF预览."""
    img_lookup = {img["id"]: img for img in coco_data["images"]}
    samples = list(coco_data["annotations"])
    random.shuffle(samples)
    samples = samples[:n_samples]

    with PdfPages(output_pdf) as pdf:
        for ann in samples:
            img_meta = img_lookup.get(ann["image_id"])
            if img_meta is None:
                continue
            img_path = os.path.join(dataset_root, img_meta["file_name"]) if dataset_root else img_meta["file_name"]
            if os.path.exists(img_path):
                img = Image.open(img_path).convert("RGB")
            else:
                img = Image.new("RGB", (img_meta["width"], img_meta["height"]), (240, 240, 240))

            fig, ax = plt.subplots(figsize=(10, 6), dpi=150)
            title = (f"{img_meta.get('dance_category', '')} / {img_meta.get('combo_id', '')} "
                     f"/ {img_meta.get('camera_view', '')}")
            draw_keypoints_on_axis(ax, img, ann["keypoints"], title=title)
            pdf.savefig(fig, bbox_inches="tight")
            plt.close(fig)

    print(f"已导出预览PDF: {output_pdf} ({n_samples} 帧)")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--annotation", required=True, help="COCO格式标注JSON路径")
    p.add_argument("--root", default=None, help="数据集根目录 (用于解析frames路径)")
    p.add_argument("--image_id", type=int, default=None, help="单帧可视化的image_id")
    p.add_argument("--output", default="visualized.png", help="单帧可视化输出路径")
    p.add_argument("--batch_pdf", default=None, help="批量PDF输出路径")
    p.add_argument("--n", type=int, default=20, help="批量抽样数量")
    args = p.parse_args()

    with open(args.annotation, "r", encoding="utf-8") as f:
        coco = json.load(f)

    if args.batch_pdf:
        batch_to_pdf(coco, args.root, args.batch_pdf, n_samples=args.n)
    elif args.image_id is not None:
        visualize_one(coco, args.image_id, args.root, args.output)
    else:
        print("请指定 --image_id 或 --batch_pdf 之一")
