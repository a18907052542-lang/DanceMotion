# DanceMotion-2024

A Multi-style Dance Pose Dataset for Real-time Motion Trajectory Reconstruction
舞蹈动作轨迹实时重建多风格姿态数据集

---

## 简介 / Overview

DanceMotion-2024 是一个面向真实舞蹈场景的二维人体姿态数据集，覆盖中国古典舞、民族舞、芭蕾舞、现代舞、街舞五大风格，包含 15 位舞者表演的 100 组标准动作组合，由两台同步相机以 90° 夹角双视角采集，共获取 600 段原始视频与 45,000 张精标关键帧。该数据集为论文《基于深度卷积网络的舞蹈动作轨迹实时重建与分析》提供训练/验证/测试基础。

DanceMotion-2024 is a 2D human-pose dataset for real-time dance scene reconstruction, covering five styles (Chinese Classical, Chinese Ethnic, Ballet, Modern, Street). It comprises 15 dancers performing 100 standardized combinations, captured by two synchronized cameras (90° configuration), yielding 600 raw videos and 45,000 carefully annotated keyframes.

---

## 数据集规格 / Statistics

| 项目 / Item                 | 数值 / Value                                      |
| :-------------------------- | :------------------------------------------------ |
| 参与舞者 / Dancers          | 15 (8 female, 7 male)                             |
| 年龄范围 / Age range        | 19–34 (mean 24.3, SD 4.2)                         |
| BMI 范围                    | 18.1–23.7 kg/m²                                   |
| 舞蹈类别 / Dance categories | 5 (Classical, Ethnic, Ballet, Modern, Street)     |
| 动作组合 / Combinations     | 100 (20 per category)                             |
| 录制场次 / Sessions         | 300                                               |
| 视频文件 / Video files      | 600 (front + side)                                |
| 视频规格 / Video specs      | 1920×1080, 60 fps, H.264/AVC                      |
| 标注帧数 / Annotated frames | 45,000                                            |
| 关键点定义 / Keypoint def.  | COCO 17 keypoints                                 |
| 数据划分 / Split            | 31,500 train / 4,500 val / 9,000 test (7:1:2)     |
| 标注一致性 / Cohen's κ      | 0.89 (avg) — Classical/Ballet 0.91, Street 0.87   |
| 平均可见率 / Avg visibility | 89.3% (Classical/Ballet 92.1%, Street 84.7%)      |
| 数据增强 / Augmentation     | 4× (training only, online random composition)     |
| 采集周期 / Collection span  | 3 months (March–May 2024)                         |

---

## 目录结构 / Directory Structure

```
DanceMotion-2024/
├── videos/                     原始视频 (600 × MP4)
│   ├── classical/             中国古典舞
│   ├── ethnic/                民族舞
│   ├── ballet/                芭蕾舞
│   ├── modern/                现代舞
│   └── street/                街舞
├── frames/                     抽取关键帧 (45,000 × JPEG)
├── annotations/
│   ├── coco/                  COCO 格式 (train/val/test.json)
│   ├── per_frame/             单帧 JSON (45,000 文件)
│   └── per_session/           整场次 JSON (300 文件)
├── metadata/                   元数据 (参与者/组合/场次/划分等 CSV)
├── documentation/              文档 (规范手册/采集协议/伦理材料)
├── code/                       工具脚本 (DataLoader/可视化/预处理)
└── quality_control/            质量控制 (κ/仲裁记录)
```

详见 `documentation/图2_数据集目录树结构.png`.

---

## 关键点定义 / Keypoint Definition

COCO 17 人体关键点标准，索引 0–16:

| 索引 / Index | 英文 / English  | 中文 / Chinese | 部位 / Region | 标注难度 / Difficulty |
| :----------: | :-------------- | :------------- | :------------ | :-------------------: |
| 0            | Nose            | 鼻尖           | Head          | Low                   |
| 1            | Left_Eye        | 左眼           | Head          | Low                   |
| 2            | Right_Eye       | 右眼           | Head          | Low                   |
| 3            | Left_Ear        | 左耳           | Head          | Mid                   |
| 4            | Right_Ear       | 右耳           | Head          | Mid                   |
| 5            | Left_Shoulder   | 左肩           | Upper limb    | Low                   |
| 6            | Right_Shoulder  | 右肩           | Upper limb    | Low                   |
| 7            | Left_Elbow      | 左肘           | Upper limb    | Mid                   |
| 8            | Right_Elbow     | 右肘           | Upper limb    | Mid                   |
| 9            | Left_Wrist      | 左腕           | Upper limb    | **High**              |
| 10           | Right_Wrist     | 右腕           | Upper limb    | **High**              |
| 11           | Left_Hip        | 左髋           | Torso         | Low                   |
| 12           | Right_Hip       | 右髋           | Torso         | Low                   |
| 13           | Left_Knee       | 左膝           | Lower limb    | Mid                   |
| 14           | Right_Knee      | 右膝           | Lower limb    | Mid                   |
| 15           | Left_Ankle      | 左踝           | Lower limb    | **High**              |
| 16           | Right_Ankle     | 右踝           | Lower limb    | **High**              |

可见性编码 / Visibility code: `0 = not visible, 1 = occluded but inferable, 2 = fully visible`.

详见 `documentation/图1_17关键点骨架示意图.png`.

---

## 快速使用 / Quick Start

### Python (PyTorch)

```python
from scripts.dataset_loader import build_dataloader

train_loader = build_dataloader(
    root="/path/to/DanceMotion-2024",
    split="train",
    batch_size=32,
    num_workers=8,
    augmentation_cfg="configs/augmentation.yaml",
)

for imgs, heatmaps, vis, meta in train_loader:
    # imgs: [B, 3, 384, 384]
    # heatmaps: [B, 17, 96, 96]
    # vis: [B, 17]
    # meta: list of dict (session_id, dancer_id, category, view, frame_idx)
    ...
```

### 单帧可视化 / Single-frame Visualization

```bash
python code/visualize_keypoints.py \
    --annotation annotations/coco/test.json \
    --root /path/to/DanceMotion-2024 \
    --image_id 42 \
    --output preview_42.png
```

### 批量预览PDF / Batch PDF Preview

```bash
python code/visualize_keypoints.py \
    --annotation annotations/coco/val.json \
    --root /path/to/DanceMotion-2024 \
    --batch_pdf preview_val.pdf --n 30
```

---

## 数据采集 / Data Collection

- **场地**：8m × 6m 专业舞蹈排练厅，5m × 4m 净空表演区
- **相机**：Sony Alpha 7S III × 2，Sony FE 24-70mm F2.8 GM 镜头
- **机位**：CAM-A 正面（光轴距舞者 4.5m），CAM-B 侧面 90°（光轴 4.2m）
- **同步**：Tentacle Sync-E 时间码（< 1 帧偏差）
- **灯光**：ARRI SkyPanel × 3，三点照明，5600K
- **录音**：棚内静音录制，音乐通过监听耳机回放（保证视频音频分离与无版权污染）

详见 `documentation/图3_双机位拍摄场景平面布置图.png` 与 `documentation/数据采集协议.docx`.

---

## 标注流程 / Annotation Workflow

- **工具**：CVAT v2.7（双人独立标注 + 第三方仲裁）
- **标注员**：5 名（A01–A05），均完成 24 学时培训并通过 κ ≥ 0.85 准入考核
- **流程**：双人独立标注 → 自动比对 → 像素偏差 > 5px 进入仲裁
- **质控**：Cohen's κ 0.89（aggregate）；分类别 κ 详见 `quality_control/kappa_per_category.csv`

详见 `documentation/标注规范手册.docx`.

---

## 许可与引用 / License & Citation

### 许可 / License
本数据集仅限学术研究使用 (CC BY-NC 4.0)，禁止商业用途。引用本数据集需同时引用相应论文。
The dataset is released under **CC BY-NC 4.0** for academic research only. Commercial use is prohibited.

### 引用 / Citation (BibTeX)

```bibtex
@article{dancemotion2024,
  title    = {Real-time Reconstruction and Analysis of Dance Motion
              Trajectories Based on Deep Convolutional Networks},
  journal  = {(submission under review)},
  year     = {2024},
  note     = {DanceMotion-2024 dataset, self-collected at Hengshui
              University Department of Sports.}
}
```

---

## 伦理与隐私 / Ethics & Privacy

- **伦理审批**：经衡水学院体育学院伦理委员会审批通过（文号见 `documentation/伦理审批文件.pdf`）
- **知情同意**：全部 15 位舞者签署书面知情同意书，授权学术使用（见 `documentation/知情同意书模板.pdf`）
- **隐私保护**：发布版本中所有舞者编号已匿名化（D01–D15），原始姓名不出现在任何公开材料

---

## 局限与已知问题 / Limitations & Known Issues

- 数据集采集于单一专业排练厅环境，户外/弱光/极端场景下的泛化性需结合 Human3.6M、Penn Action 等公开数据集进行交叉验证
- 街舞类别中地面动作（如 Headspin/Windmill）平均可见率偏低（84.7%），下肢遮挡较多
- 当前版本仅含二维关键点；三维重建可通过双视角 DLT 算法离线获得（参考论文第 4.3 节）

---

## 联系方式 / Contact

如有数据使用问题、勘误反馈或合作需求，请通过论文通讯作者邮箱联系。
For data usage inquiries or collaboration, please contact the corresponding author of the associated paper.

---

**Last updated:** 2024-08-15
