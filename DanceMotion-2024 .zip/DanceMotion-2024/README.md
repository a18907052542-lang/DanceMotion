# DanceMotion-2024

> A multi-style dance pose benchmark containing **45,000** annotated frames across **5** dance genres,
> released to facilitate reproducible research in real-time dance motion trajectory reconstruction.

[![License: CC BY-NC 4.0](https://img.shields.io/badge/License-CC%20BY--NC%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by-nc/4.0/)
[![Format: COCO](https://img.shields.io/badge/format-COCO%2017--kpt-blue.svg)]()
[![Frames](https://img.shields.io/badge/frames-45%2C000-success.svg)]()

<p align="center">
  <img src="assets/keypoint_skeleton.png" width="42%" />
  <img src="assets/recording_setup.png" width="55%" />
</p>

---

## 📋 Overview

DanceMotion-2024 is a high-quality multi-style dance motion pose dataset constructed
specifically for the unique kinematic and visual characteristics of dance movements,
addressing the gap that existing public datasets are primarily designed for daily
actions and do not adequately cover the diversity of dance.

| Property | Value |
| --- | --- |
| Total annotated frames | **45,000** |
| Dance genres           | **5** (Chinese Classical, Ethnic, Ballet, Modern, Street) |
| Dancers                | **15** (8 female, 7 male; aged 19–34, mean 24.3 ± 4.2) |
| Recording sessions     | **300** |
| Videos                 | **600** (dual-view, 1920×1080 @ 60fps) |
| Keypoints per frame    | **17** (COCO format) |
| Train / Val / Test     | **31,500 / 4,500 / 9,000** (7 : 1 : 2) |
| Inter-annotator agreement (Cohen κ) | **0.89** (near-perfect) |
| Average keypoint visibility | **89.3 %** |
| License                | CC BY-NC 4.0 |

## 🗂 Dataset Structure

```
DanceMotion-2024/
├── docs/                              # Annotation protocol & data collection guidelines
│   ├── Annotation_Guidelines_Manual.docx
│   ├── Data_Collection_Protocol.docx
│   └── DATASET_OVERVIEW.md
├── annotations/                       # Annotation files & manifests
│   ├── representative_annotations.json   # 50 representative frames (10 per genre)
│   ├── dataset_split.csv                  # Full 45,000-frame train/val/test assignment
│   └── file_md5_manifest.txt              # MD5 checksums for all videos/annotations
├── configs/
│   └── augmentation.yaml              # Recommended data-augmentation pipeline
├── scripts/                           # User-side data utilities
│   ├── dataset_loader.py              # PyTorch Dataset / DataLoader
│   └── visualize_keypoints.py         # Keypoint overlay & batch PDF export
├── assets/                            # Reference figures
│   ├── keypoint_skeleton.png
│   ├── directory_structure.png
│   └── recording_setup.png
├── statistics/
│   └── dataset_statistics.xlsx        # 13-sheet workbook of per-category statistics
├── README.md                          # This file
├── CITATION.cff
├── LICENSE
└── .gitignore
```

## 🎯 Five Dance Categories

| Category | Action combinations | Annotated frames | Avg. visibility | Avg. MPJPE¹ |
| --- | --- | --- | --- | --- |
| Chinese Classical Dance | 20 | 9,000 | 92.1 % | 43.7 mm |
| Ethnic Dance            | 20 | 9,000 | 90.5 % | 45.2 mm |
| Ballet                  | 20 | 9,000 | 92.1 % | 41.3 mm |
| Modern Dance            | 20 | 9,000 | 88.1 % | 48.6 mm |
| Street Dance            | 20 | 9,000 | 84.7 % | 54.8 mm |

¹ Measured by the proposed pose estimation network reported in the companion paper.

## 🏷 Keypoint Definition (COCO 17-keypoint convention)

<p align="center">
  <img src="assets/keypoint_skeleton.png" width="55%" />
</p>

| Index | Name | Anatomical landmark |
| --- | --- | --- |
| 0 | Nose | Tip of the nose |
| 1, 2 | Left / Right Eye | Pupil centre |
| 3, 4 | Left / Right Ear | Anterior margin of the tragus |
| 5, 6 | Left / Right Shoulder | Lateral margin of acromion |
| 7, 8 | Left / Right Elbow | Lateral epicondyle of the humerus |
| 9, 10 | Left / Right Wrist | Ulnar styloid process |
| 11, 12 | Left / Right Hip | Greater trochanter of the femur |
| 13, 14 | Left / Right Knee | Centre of the patella |
| 15, 16 | Left / Right Ankle | Lateral malleolus |

A detailed protocol — including visibility coding, occlusion taxonomy, and
quality-control procedure — is provided in
[`docs/Annotation_Guidelines_Manual.docx`](docs/Annotation_Guidelines_Manual.docx).

## 🚀 Quick Start

### 1. Clone the repository

```bash
git clone https://github.com/[username]/DanceMotion-2024.git
cd DanceMotion-2024
```

### 2. Download the full dataset

Due to GitHub's file-size limit, only the protocol, scripts and representative
annotations are versioned here. Request the **45,000-frame** annotations and the
**600 video files** (≈ 320 GB total) via the dataset release link below.

> ✉️ **Dataset access**: Send a brief description of your research intent to the
> corresponding author (see `CITATION.cff`). Upon non-commercial-use confirmation,
> a download link (Zenodo / OneDrive / OSS) will be provided.

### 3. Install requirements

```bash
pip install -r requirements.txt
```

(Required packages: `torch`, `torchvision`, `opencv-python`, `numpy`,
`Pillow`, `tqdm`, `PyYAML`.)

### 4. Load the dataset

```python
from scripts.dataset_loader import DanceMotionDataset

ds = DanceMotionDataset(
    root="/path/to/DanceMotion-2024",
    split="train",                 # or "val", "test"
    image_size=(256, 192),
    heatmap_size=(64, 48),
)
print(len(ds), "samples")
img, heatmap, weight, kpts, meta = ds[0]
```

### 5. Visualise keypoints

```bash
python scripts/visualize_keypoints.py \
    --root      /path/to/DanceMotion-2024 \
    --split     test \
    --output    visualisations/ \
    --num       30
```

## 📈 Data Collection Setup

DanceMotion-2024 was collected in a fixed dance training studio with strictly
controlled lighting, two synchronised industrial cameras (front + side at 90°),
60 fps progressive recording at 1920×1080. The full protocol is described in
[`docs/Data_Collection_Protocol.docx`](docs/Data_Collection_Protocol.docx).

<p align="center">
  <img src="assets/recording_setup.png" width="70%" />
</p>

Key environmental controls:
- Temperature: 22 ± 2 °C, RH 45 ± 10 %
- Three-point ARRI SkyPanel LED lighting (CRI ≥ 95, flicker-free above 25 kHz)
- Hardware time-code synchronisation (< 1 frame drift)
- Centre-of-stage illuminance 1,200 ± 100 lux

## 📊 Data Annotation Quality

- **Two-pass + arbitration** workflow on the CVAT v2.7 platform
- **Two-week** annotator training programme followed by certification
- Annotations exceeding **5 px** discrepancy between the two annotators trigger
  a third arbitration round
- Final **Cohen κ = 0.89** (near-perfect agreement)
- Overall keypoint visibility **89.3 %**

| Skill / Body region | Avg. visibility |
| --- | --- |
| Classical & Ballet (full-stretch postures) | 92.1 % |
| Ethnic & Modern (mixed) | 89.3 % |
| Street (floor & rapid rotations) | 84.7 % |

## 🔁 Data Augmentation

A complete reference augmentation pipeline tuned for dance scenes is provided
in [`configs/augmentation.yaml`](configs/augmentation.yaml). The pipeline yields
**4 × expansion** of the training set and contains two dance-specific operators:

- **Stage-lighting gradient**: simulates stage-light intensity variation across
  the image plane.
- **Direction-aware motion blur**: applies orientation-aware blur kernels along
  dominant motion gradients to mimic motion drag during rapid posture transitions.

## ⚖️ Ethics & License

This dataset was approved by the **Ethics Committee of the College of Physical
Education of Hengshui University** under the principles of the Declaration of
Helsinki. All dancers provided **written informed consent**. Faces are blurred
via Gaussian masking; personal identifiers are replaced by anonymous IDs
(`D01–D15`). Original identity records are sealed and retained by the project
PI for **10 years**.

Distributed under the **Creative Commons Attribution-NonCommercial 4.0**
(CC BY-NC 4.0) license. Permitted uses include academic research and education.
Commercial use, identity recognition, surveillance, or any application that
violates the dancers' informed consent is **strictly prohibited**.

See [LICENSE](LICENSE) for full terms.

## 📚 Citation

If you use DanceMotion-2024 in your work, please cite:

```bibtex
@dataset{tang2024dancemotion,
  title  = {DanceMotion-2024: A Multi-style Dance Pose Benchmark for Real-time
            Motion Trajectory Reconstruction},
  author = {Tang, Tang and Yuan, Guoliang and Wang, Xiaofeng and Sun, Zengjun},
  year   = {2024},
  note   = {Hengshui University Dance Research Group},
  url    = {https://github.com/[username]/DanceMotion-2024},
  license = {CC BY-NC 4.0}
}
```

Companion paper (network architecture & experimental results):

```bibtex
@article{tang2025dancereconstruction,
  title  = {Real-time Reconstruction and Analysis of Dance Motion Trajectories
            Based on Deep Convolutional Networks},
  author = {Tang, Tang and Yuan, Guoliang and Wang, Xiaofeng and Sun, Zengjun},
  year   = {2025}
}
```

## 🔗 Related Repository

The reference implementation of the proposed network, including the
graph-Laplacian observation refinement, the extended Kalman filter pipeline,
and the multi-dimensional motion feature analyser, is available at:

- **[DanceMotion-Reconstruction](https://github.com/[username]/DanceMotion-Reconstruction)** —
  PyTorch implementation, seven baseline comparisons, full result reproduction.

## 🛠 Acknowledgements

This dataset was constructed by the Dance Research Group at Hengshui University.
We thank the **15 participating dancers** from Hengshui University, professional
dance academies, and university dance teams who generously contributed their
performances to advance dance motion analysis research.

## 📨 Contact

For questions about dataset access, annotation conventions, or collaboration
opportunities, please contact the corresponding author listed in `CITATION.cff`.
