# -*- coding: utf-8 -*-
"""Evaluation metrics for pose estimation and trajectory reconstruction.

Implements:
    1. MPJPE — Mean Per-Joint Position Error (in pixels or millimetres).
    2. PCK   — Percentage of Correct Keypoints under a given threshold.
    3. AP    — Average Precision based on Object Keypoint Similarity (OKS).
    4. Trajectory jitter — mean per-frame L2 displacement.
"""
from __future__ import annotations
import numpy as np


# COCO keypoint OKS sigmas (per the COCO keypoint evaluation protocol)
COCO_OKS_SIGMAS = np.array([
    0.026, 0.025, 0.025, 0.035, 0.035,
    0.079, 0.079, 0.072, 0.072, 0.062, 0.062,
    0.107, 0.107, 0.087, 0.087, 0.089, 0.089,
], dtype=np.float64)


def mpjpe(pred: np.ndarray, gt: np.ndarray, vis: np.ndarray = None) -> float:
    """Mean Per-Joint Position Error.

    Args:
        pred: (N, 17, 2) predicted coordinates (pixels or mm).
        gt:   (N, 17, 2) ground-truth coordinates.
        vis:  (N, 17) optional visibility mask (>0 → use).
    Returns:
        scalar MPJPE in the same unit as the input.
    """
    diffs = np.linalg.norm(pred - gt, axis=-1)   # (N, 17)
    if vis is not None:
        mask = (vis > 0).astype(np.float64)
        if mask.sum() == 0:
            return 0.0
        return float((diffs * mask).sum() / mask.sum())
    return float(diffs.mean())


def pck(pred: np.ndarray, gt: np.ndarray,
        threshold: float = 0.5,
        reference_length: np.ndarray = None,
        vis: np.ndarray = None) -> float:
    """Percentage of Correct Keypoints.

    Args:
        pred, gt: (N, 17, 2) arrays.
        threshold: fraction of reference_length used as the acceptance radius.
        reference_length: (N,) reference length per sample (e.g., torso diagonal).
                          If None, the bounding-box diagonal is used.
        vis: (N, 17) visibility mask.
    Returns:
        PCK as a fraction in [0, 1].
    """
    N, K, _ = pred.shape
    diffs = np.linalg.norm(pred - gt, axis=-1)   # (N, K)
    if reference_length is None:
        x_min = gt[:, :, 0].min(axis=1)
        x_max = gt[:, :, 0].max(axis=1)
        y_min = gt[:, :, 1].min(axis=1)
        y_max = gt[:, :, 1].max(axis=1)
        reference_length = np.sqrt((x_max - x_min) ** 2 + (y_max - y_min) ** 2)
    accepted = diffs < threshold * reference_length[:, None]   # (N, K)
    if vis is not None:
        mask = vis > 0
        return float(accepted[mask].mean()) if mask.sum() else 0.0
    return float(accepted.mean())


def per_keypoint_pck(pred: np.ndarray, gt: np.ndarray,
                      threshold: float = 0.5,
                      reference_length: np.ndarray = None,
                      vis: np.ndarray = None) -> np.ndarray:
    """Per-keypoint PCK — used to reproduce Table 7."""
    N, K, _ = pred.shape
    diffs = np.linalg.norm(pred - gt, axis=-1)
    if reference_length is None:
        x_min = gt[:, :, 0].min(axis=1); x_max = gt[:, :, 0].max(axis=1)
        y_min = gt[:, :, 1].min(axis=1); y_max = gt[:, :, 1].max(axis=1)
        reference_length = np.sqrt((x_max - x_min) ** 2 + (y_max - y_min) ** 2)
    accepted = diffs < threshold * reference_length[:, None]
    if vis is not None:
        mask = vis > 0
    else:
        mask = np.ones_like(accepted, dtype=bool)
    per_kpt = np.zeros(K, dtype=np.float64)
    for k in range(K):
        m = mask[:, k]
        per_kpt[k] = accepted[m, k].mean() if m.sum() else 0.0
    return per_kpt


def oks(pred: np.ndarray, gt: np.ndarray,
        bbox_area: float,
        vis: np.ndarray = None,
        sigmas: np.ndarray = None) -> float:
    """Object Keypoint Similarity for a single instance."""
    if sigmas is None:
        sigmas = COCO_OKS_SIGMAS
    d_squared = np.sum((pred - gt) ** 2, axis=-1)        # (K,)
    s = bbox_area + 1e-9
    k_vars = (sigmas * 2) ** 2
    if vis is None:
        e = np.exp(-d_squared / (2 * s * k_vars))
        return float(e.mean())
    mask = vis > 0
    if mask.sum() == 0:
        return 0.0
    e = np.exp(-d_squared / (2 * s * k_vars))
    return float(e[mask].mean())


def average_precision_oks(pred_list: list,
                            gt_list:   list,
                            thresholds: np.ndarray = None) -> float:
    """Average Precision based on OKS, averaged over multiple thresholds.

    Args:
        pred_list: list of dicts {"keypoints": (17, 2), "score": float}.
        gt_list:   list of dicts {"keypoints": (17, 2), "vis": (17,), "bbox_area": float}.
        thresholds: array of OKS thresholds; defaults to the COCO 0.50:0.05:0.95 set.
    Returns:
        scalar AP value in [0, 1].
    """
    if thresholds is None:
        thresholds = np.arange(0.50, 0.96, 0.05)

    N = min(len(pred_list), len(gt_list))
    ap_values = []
    for thr in thresholds:
        tp = 0
        for i in range(N):
            oks_i = oks(pred_list[i]["keypoints"], gt_list[i]["keypoints"],
                         bbox_area=gt_list[i]["bbox_area"], vis=gt_list[i].get("vis"))
            if oks_i >= thr:
                tp += 1
        ap_values.append(tp / max(N, 1))
    return float(np.mean(ap_values))


def trajectory_jitter(seq: np.ndarray) -> float:
    """Mean per-frame L2 displacement (pixels)."""
    if seq.shape[0] < 2:
        return 0.0
    diffs = np.linalg.norm(np.diff(seq, axis=0), axis=-1)   # (T-1, K)
    return float(diffs.mean())


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    N = 100
    gt = rng.uniform(50, 200, size=(N, 17, 2))
    pred = gt + rng.normal(scale=4, size=gt.shape)
    vis = np.ones((N, 17))
    print(f"MPJPE      : {mpjpe(pred, gt, vis):.3f} px")
    print(f"PCK@0.5    : {pck(pred, gt, threshold=0.5, vis=vis) * 100:.2f} %")
    pkpt = per_keypoint_pck(pred, gt, threshold=0.5, vis=vis)
    print(f"Per-kpt PCK shape : {pkpt.shape}, mean = {pkpt.mean() * 100:.2f} %")
    print(f"Trajectory jitter : {trajectory_jitter(pred):.3f} px")
