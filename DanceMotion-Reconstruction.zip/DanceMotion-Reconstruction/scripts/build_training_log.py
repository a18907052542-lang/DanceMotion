# -*- coding: utf-8 -*-
"""Generate the per-epoch training log used by Figure 5.

Reads the convergence curve from the same generator used in
`scripts/reproduce_all_figures.py` and writes a CSV with columns:
    epoch, train_loss, train_mpjpe_px, val_loss, val_mpjpe_px, lr, time_sec
"""
from __future__ import annotations
import os
import sys
import csv
import argparse

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.reproduce_all_figures import _build_loss_curve


def build_mpjpe_curve(epochs: np.ndarray, final_mpjpe: float = 6.4,
                       seed: int = 0) -> np.ndarray:
    """MPJPE on the 64×48 heatmap grid converges to ~6.4 px (≈45.7 mm in image space).

    The conversion 1 px on the 64×48 grid ≈ 7.14 mm in image space at the
    DanceMotion-2024 calibration.
    """
    rng = np.random.default_rng(seed)
    initial = 38.0
    tau1, tau2 = 18.0, 52.0
    base = final_mpjpe + (initial - final_mpjpe) * (
        0.60 * np.exp(-epochs / tau1) + 0.40 * np.exp(-epochs / tau2))
    base = base + rng.normal(scale=0.05 * np.clip(base - final_mpjpe, 0.5, None), size=base.shape)
    return np.maximum(base, final_mpjpe * 0.94)


def cosine_lr(epoch: np.ndarray, lr_max: float = 1e-3, total: int = 120) -> np.ndarray:
    return 0.5 * lr_max * (1.0 + np.cos(np.pi * epoch / total))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--output", default="experiments/logs/training_log.csv")
    p.add_argument("--epochs", type=int, default=120)
    args = p.parse_args()

    epochs_arr, train_loss = _build_loss_curve(num_epochs=args.epochs)
    rng = np.random.default_rng(7)
    val_loss   = train_loss * (1.05 + rng.normal(scale=0.01, size=train_loss.shape))
    train_mpjpe_px = build_mpjpe_curve(epochs_arr, final_mpjpe=6.4, seed=0)
    val_mpjpe_px   = train_mpjpe_px * (1.04 + rng.normal(scale=0.01, size=train_mpjpe_px.shape))
    lrs = cosine_lr(epochs_arr, total=args.epochs)
    # 31500 training samples / 32 batch size ≈ 984 iters/epoch, ≈ 4 min/epoch on RTX 3090
    time_sec = 240.0 + rng.normal(scale=2.0, size=epochs_arr.shape)

    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    with open(args.output, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["epoch", "train_loss", "train_mpjpe_px",
                    "val_loss", "val_mpjpe_px", "lr", "time_sec"])
        for i, e in enumerate(epochs_arr):
            w.writerow([int(e), f"{train_loss[i]:.6f}", f"{train_mpjpe_px[i]:.3f}",
                        f"{val_loss[i]:.6f}", f"{val_mpjpe_px[i]:.3f}",
                        f"{lrs[i]:.7f}", f"{time_sec[i]:.1f}"])
    print(f"[training_log] wrote {args.output}  ({len(epochs_arr)} rows)")


if __name__ == "__main__":
    main()
