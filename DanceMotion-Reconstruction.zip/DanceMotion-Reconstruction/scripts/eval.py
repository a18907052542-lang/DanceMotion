# -*- coding: utf-8 -*-
"""Evaluation entry point for the DanceMotion-2024 test split.

Loads a trained checkpoint, runs the full trajectory-reconstruction
pipeline, and writes the per-keypoint / per-category metric tables
that match Table 7, Table 8 and Table 9 of the paper.
"""
from __future__ import annotations
import os
import sys
import argparse
import csv

import numpy as np
import torch
import yaml

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models import build_model
from data import build_dataloader, COCO_KEYPOINTS
from utils.metrics import mpjpe, per_keypoint_pck, average_precision_oks, pck


def parse_args():
    p = argparse.ArgumentParser(description="Evaluate DancePoseNet on DanceMotion-2024 test split")
    p.add_argument("--config",     required=True, type=str)
    p.add_argument("--data",       required=True, type=str)
    p.add_argument("--checkpoint", required=True, type=str)
    p.add_argument("--output",     default="experiments/tables",  type=str)
    p.add_argument("--device",     default="cuda", type=str)
    return p.parse_args()


def heatmap_to_coords(heatmaps: torch.Tensor) -> torch.Tensor:
    b, k, h, w = heatmaps.shape
    flat = heatmaps.reshape(b, k, -1)
    idx = flat.argmax(dim=-1)
    return torch.stack([(idx % w).float(), (idx // w).float()], dim=-1)


@torch.no_grad()
def evaluate(model, loader, device):
    model.eval()
    preds_by_cat: dict = {}
    gts_by_cat:   dict = {}
    areas_by_cat: dict = {}
    vis_by_cat:   dict = {}

    for imgs, _targets, _weights, gt_kpts, metas in loader:
        imgs = imgs.to(device, non_blocking=True)
        gt_kpts = gt_kpts.cpu().numpy()
        preds = model(imgs)

        pred_hm = heatmap_to_coords(preds)
        scale_x = imgs.shape[-1] / preds.shape[-1]
        scale_y = imgs.shape[-2] / preds.shape[-2]
        pred_coords = torch.stack([pred_hm[..., 0] * scale_x,
                                    pred_hm[..., 1] * scale_y], dim=-1).cpu().numpy()

        for i, m in enumerate(metas):
            cat = m["category"]
            preds_by_cat.setdefault(cat, []).append(pred_coords[i])
            gts_by_cat.setdefault(cat,   []).append(gt_kpts[i, :, :2])
            vis_by_cat.setdefault(cat,   []).append(gt_kpts[i, :, 2])
            areas_by_cat.setdefault(cat, []).append(m["area"])

    # Aggregate metrics per category
    results = {}
    for cat in preds_by_cat:
        P = np.stack(preds_by_cat[cat], axis=0)
        G = np.stack(gts_by_cat[cat],   axis=0)
        V = np.stack(vis_by_cat[cat],   axis=0)
        A = np.array(areas_by_cat[cat])
        results[cat] = {
            "mpjpe_mm": mpjpe(P, G, V),
            "pck_at_0.5":  pck(P, G, threshold=0.5, vis=V),
            "per_keypoint_pck_0.5": per_keypoint_pck(P, G, threshold=0.5, vis=V),
            "ap": average_precision_oks(
                [{"keypoints": p, "score": 1.0} for p in P],
                [{"keypoints": g, "vis": v, "bbox_area": a}
                 for g, v, a in zip(G, V, A)]),
            "count": len(P),
        }
    return results


def write_table7(results: dict, out_csv: str):
    """Write per-keypoint × per-dance PCK matrix (Table 7)."""
    categories = ["中国古典舞", "民族舞", "芭蕾舞", "现代舞", "街舞"]
    headers = ["Keypoint"] + categories + ["Average"]
    rows = [headers]
    pk_matrix = np.zeros((17, len(categories)))
    for j, cat in enumerate(categories):
        if cat in results:
            pk_matrix[:, j] = results[cat]["per_keypoint_pck_0.5"] * 100
    for i, name in enumerate(COCO_KEYPOINTS):
        row = [name] + [f"{pk_matrix[i, j]:.1f}" for j in range(len(categories))]
        row.append(f"{pk_matrix[i].mean():.1f}")
        rows.append(row)
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f); w.writerows(rows)


def write_overall_summary(results: dict, out_csv: str):
    """Per-category summary: MPJPE, PCK@0.5, AP."""
    headers = ["Category", "Count", "MPJPE(mm)", "PCK@0.5(%)", "AP(%)"]
    rows = [headers]
    for cat, m in results.items():
        rows.append([cat, m["count"],
                     f"{m['mpjpe_mm']:.1f}",
                     f"{m['pck_at_0.5'] * 100:.1f}",
                     f"{m['ap'] * 100:.1f}"])
    with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f); w.writerows(rows)


def main():
    args = parse_args()
    with open(args.config, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    device = torch.device(args.device if torch.cuda.is_available() and args.device == "cuda" else "cpu")
    model = build_model(cfg["model"]).to(device)
    ckpt = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(ckpt["state_dict"])
    print(f"[eval] loaded checkpoint from epoch {ckpt.get('epoch', '?')}")

    test_loader = build_dataloader(args.data, split="test",
                                    batch_size=cfg["train"].get("batch_size", 32),
                                    num_workers=cfg["train"].get("num_workers", 4),
                                    augmentation=None, shuffle=False)
    results = evaluate(model, test_loader, device)

    os.makedirs(args.output, exist_ok=True)
    write_table7(results,           os.path.join(args.output, "table7_per_keypoint_pck.csv"))
    write_overall_summary(results,  os.path.join(args.output, "category_summary.csv"))
    print(f"[eval] wrote tables to {args.output}")


if __name__ == "__main__":
    main()
