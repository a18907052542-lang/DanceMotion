# -*- coding: utf-8 -*-
"""Inference benchmark for the proposed DancePoseNet.

Measures single-frame inference time and batch throughput across
multiple input resolutions and batch sizes. Reproduces Table 8 of
the paper.

Usage:
    python scripts/benchmark.py --config configs/dance_pose_default.yaml \
                                 --output experiments/tables/table8_inference.csv
"""
from __future__ import annotations
import os
import sys
import time
import argparse
import csv

import numpy as np
import torch
import yaml

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models import build_model


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="configs/dance_pose_default.yaml")
    p.add_argument("--output", default="experiments/tables/table8_inference.csv")
    p.add_argument("--device", default="cuda")
    p.add_argument("--warmup", type=int, default=20)
    p.add_argument("--repeat", type=int, default=200)
    return p.parse_args()


def measure_inference(model, resolution, batch_size, device, warmup=20, repeat=200):
    H, W = resolution
    x = torch.randn(batch_size, 3, H, W, device=device)

    # Warm-up
    with torch.no_grad():
        for _ in range(warmup):
            _ = model(x)
        if device.type == "cuda":
            torch.cuda.synchronize()

    # Time
    times = []
    with torch.no_grad():
        for _ in range(repeat):
            if device.type == "cuda":
                torch.cuda.synchronize()
            t0 = time.time()
            _ = model(x)
            if device.type == "cuda":
                torch.cuda.synchronize()
            times.append((time.time() - t0) * 1000.0)
    times = np.array(times)
    return float(times.mean()), float(times.std())


def main():
    args = parse_args()
    with open(args.config, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    device = torch.device(args.device if torch.cuda.is_available() and args.device == "cuda" else "cpu")
    model = build_model(cfg["model"]).to(device).eval()
    print(f"[benchmark] device={device}")

    inf_cfg = cfg["inference"]
    resolutions = inf_cfg["test_resolutions"]
    batches     = inf_cfg["test_batch_sizes"]

    # Configurations from Table 8
    configurations = [
        (tuple(resolutions[0]), 1),
        (tuple(resolutions[1]), 1),
        (tuple(resolutions[2]), 1),
        (tuple(resolutions[1]), 4),
        (tuple(resolutions[1]), 8),
        (tuple(resolutions[1]), 16),
    ]

    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    with open(args.output, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["Input Resolution", "Batch Size",
                     "Inference Time (ms)", "Frame Rate (fps)",
                     "Throughput (frames/sec)"])

        for (H, W), B in configurations:
            mean_ms, std_ms = measure_inference(model, (H, W), B, device,
                                                 warmup=args.warmup, repeat=args.repeat)
            fps_single = 1000.0 / mean_ms
            throughput = (B * 1000.0) / mean_ms
            fps_str = f"{fps_single:.1f}" if B == 1 else "-"
            w.writerow([f"{W}×{H}", B,
                        f"{mean_ms:.1f}",
                        fps_str,
                        f"{throughput:.1f}"])
            print(f"  {W}×{H} bs={B:2d}: {mean_ms:.1f} ± {std_ms:.1f} ms, "
                  f"throughput={throughput:.1f} fps")
    print(f"[benchmark] wrote {args.output}")


if __name__ == "__main__":
    main()
