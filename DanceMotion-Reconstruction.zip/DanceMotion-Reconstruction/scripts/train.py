# -*- coding: utf-8 -*-
"""Training entry point for the DanceMotion-2024 pose estimation network.

Reproduces the training protocol described in Section 4.1 of the paper:
    Optimizer            : Adam
    Initial learning rate: 1e-3
    Weight decay         : 1e-4
    LR scheduler         : Cosine annealing
    Batch size           : 32
    Epochs               : 120
    Input resolution     : 256×192
    Heatmap resolution   : 64×48
    Loss                 : per-keypoint MSE (Eq. 4)

Usage:
    python scripts/train.py --config configs/dance_pose_default.yaml \
                            --data /path/to/DanceMotion-2024
"""
from __future__ import annotations
import os
import sys
import time
import argparse
import csv

import yaml
import torch
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models import build_model
from losses import HeatmapMSELoss
from data import build_dataloader
from data.augmentation import DanceAugmentation
from utils.metrics import mpjpe


def parse_args():
    p = argparse.ArgumentParser(description="Train DancePoseNet on DanceMotion-2024")
    p.add_argument("--config", type=str, default="configs/dance_pose_default.yaml",
                    help="path to the YAML training configuration")
    p.add_argument("--data",   type=str, required=True,
                    help="root directory of DanceMotion-2024")
    p.add_argument("--output", type=str, default="experiments/checkpoints",
                    help="directory to save checkpoints and logs")
    p.add_argument("--resume", type=str, default=None,
                    help="resume training from a checkpoint")
    p.add_argument("--device", type=str, default="cuda",
                    help="device — 'cuda' or 'cpu'")
    p.add_argument("--seed",   type=int, default=42)
    return p.parse_args()


def load_config(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def heatmap_to_coords(heatmaps: torch.Tensor) -> torch.Tensor:
    """Argmax decoding from heatmaps to (B, K, 2) pixel coords."""
    b, k, h, w = heatmaps.shape
    flat = heatmaps.reshape(b, k, -1)
    idx = flat.argmax(dim=-1)
    coords = torch.stack([(idx % w).float(), (idx // w).float()], dim=-1)
    return coords


def train_one_epoch(model, loader, criterion, optimizer, device, scheduler):
    model.train()
    epoch_loss = 0.0
    epoch_mpjpe = 0.0
    n_batches = 0
    n_total = 0

    for imgs, targets, weights, gt_kpts, _metas in loader:
        imgs    = imgs.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)
        weights = weights.to(device, non_blocking=True)
        gt_kpts = gt_kpts.to(device, non_blocking=True)

        optimizer.zero_grad()
        preds = model(imgs)
        loss = criterion(preds, targets, weights)
        loss.backward()
        optimizer.step()
        scheduler.step()

        epoch_loss += loss.item()
        n_batches += 1

        # Live MPJPE on the heatmap argmax (in image space)
        with torch.no_grad():
            pred_coords_hm = heatmap_to_coords(preds)
            scale_x = imgs.shape[-1] / preds.shape[-1]
            scale_y = imgs.shape[-2] / preds.shape[-2]
            pred_coords = torch.stack([
                pred_coords_hm[..., 0] * scale_x,
                pred_coords_hm[..., 1] * scale_y,
            ], dim=-1)
            diffs = torch.linalg.norm(pred_coords - gt_kpts[..., :2], dim=-1)
            epoch_mpjpe += diffs.mean().item() * imgs.size(0)
            n_total += imgs.size(0)

    return epoch_loss / max(n_batches, 1), epoch_mpjpe / max(n_total, 1)


@torch.no_grad()
def validate(model, loader, criterion, device):
    model.eval()
    total_loss = 0.0
    total_mpjpe = 0.0
    n_batches = 0
    n_total = 0
    for imgs, targets, weights, gt_kpts, _metas in loader:
        imgs    = imgs.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)
        weights = weights.to(device, non_blocking=True)
        gt_kpts = gt_kpts.to(device, non_blocking=True)
        preds = model(imgs)
        loss = criterion(preds, targets, weights)
        total_loss += loss.item()
        n_batches += 1

        pred_coords_hm = heatmap_to_coords(preds)
        scale_x = imgs.shape[-1] / preds.shape[-1]
        scale_y = imgs.shape[-2] / preds.shape[-2]
        pred_coords = torch.stack([
            pred_coords_hm[..., 0] * scale_x,
            pred_coords_hm[..., 1] * scale_y,
        ], dim=-1)
        diffs = torch.linalg.norm(pred_coords - gt_kpts[..., :2], dim=-1)
        total_mpjpe += diffs.mean().item() * imgs.size(0)
        n_total += imgs.size(0)
    return total_loss / max(n_batches, 1), total_mpjpe / max(n_total, 1)


def main():
    args = parse_args()
    torch.manual_seed(args.seed)
    cfg = load_config(args.config)

    os.makedirs(args.output, exist_ok=True)
    log_path = os.path.join(args.output, "training_log.csv")

    device = torch.device(args.device if torch.cuda.is_available() and args.device == "cuda" else "cpu")
    print(f"[device] {device}")

    aug = DanceAugmentation()
    train_loader = build_dataloader(args.data, split="train",
                                     batch_size=cfg["train"]["batch_size"],
                                     num_workers=cfg["train"]["num_workers"],
                                     augmentation=aug)
    val_loader   = build_dataloader(args.data, split="val",
                                     batch_size=cfg["train"]["batch_size"],
                                     num_workers=cfg["train"]["num_workers"],
                                     augmentation=None, shuffle=False)

    model = build_model(cfg["model"]).to(device)
    n_params = model.count_parameters() / 1e6
    print(f"[model] DancePoseNet parameters: {n_params:.2f} M")

    criterion = HeatmapMSELoss(num_keypoints=cfg["model"]["num_keypoints"])
    optimizer = optim.Adam(model.parameters(),
                            lr=cfg["train"]["lr"],
                            weight_decay=cfg["train"]["weight_decay"])
    total_steps = cfg["train"]["epochs"] * max(len(train_loader), 1)
    scheduler = CosineAnnealingLR(optimizer, T_max=total_steps)

    start_epoch = 0
    best_mpjpe = float("inf")
    if args.resume and os.path.isfile(args.resume):
        ckpt = torch.load(args.resume, map_location=device)
        model.load_state_dict(ckpt["state_dict"])
        optimizer.load_state_dict(ckpt["optimizer"])
        start_epoch = ckpt.get("epoch", 0) + 1
        best_mpjpe = ckpt.get("best_mpjpe", float("inf"))
        print(f"[resume] from epoch {start_epoch}")

    write_header = not os.path.isfile(log_path)
    with open(log_path, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if write_header:
            w.writerow(["epoch", "train_loss", "train_mpjpe_px",
                        "val_loss", "val_mpjpe_px", "lr", "time_sec"])

        for epoch in range(start_epoch, cfg["train"]["epochs"]):
            t0 = time.time()
            train_loss, train_mpjpe = train_one_epoch(model, train_loader,
                                                       criterion, optimizer,
                                                       device, scheduler)
            val_loss, val_mpjpe = validate(model, val_loader, criterion, device)
            cur_lr = optimizer.param_groups[0]["lr"]
            dt = time.time() - t0
            print(f"[epoch {epoch + 1:03d}/{cfg['train']['epochs']}] "
                  f"loss={train_loss:.4f} mpjpe={train_mpjpe:.2f}px | "
                  f"val_loss={val_loss:.4f} val_mpjpe={val_mpjpe:.2f}px | "
                  f"lr={cur_lr:.6f} t={dt:.1f}s")
            w.writerow([epoch + 1, train_loss, train_mpjpe,
                        val_loss, val_mpjpe, cur_lr, dt])
            f.flush()

            if val_mpjpe < best_mpjpe:
                best_mpjpe = val_mpjpe
                torch.save({
                    "epoch": epoch,
                    "state_dict": model.state_dict(),
                    "optimizer":  optimizer.state_dict(),
                    "best_mpjpe": best_mpjpe,
                    "config":     cfg,
                }, os.path.join(args.output, "best.pth"))

            if (epoch + 1) % 10 == 0:
                torch.save({
                    "epoch": epoch,
                    "state_dict": model.state_dict(),
                    "optimizer":  optimizer.state_dict(),
                    "best_mpjpe": best_mpjpe,
                    "config":     cfg,
                }, os.path.join(args.output, f"epoch_{epoch + 1:03d}.pth"))


if __name__ == "__main__":
    main()
