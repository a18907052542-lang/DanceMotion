# -*- coding: utf-8 -*-
"""Statistical significance analysis (Section 4.3.4 / Table 11).

Performs Bonferroni-corrected paired two-tailed t-tests on per-image
MPJPE values, comparing the proposed method against the seven baselines
across five independent random seeds (42, 123, 456, 789, 1024).

Inputs:
    experiments/results_raw/mpjpe_per_image_<method>_seed<seed>.npy
        — one (N,) array per method per seed, written by scripts/eval.py
        when invoked with --save-per-image.

Output:
    experiments/tables/table11_significance.csv

The script also accepts an offline mode (--use-paper-values) that prints
the aggregated paper-reported values without requiring the raw per-image
arrays, so the table can still be reproduced from the saved summary.
"""
from __future__ import annotations
import os
import sys
import argparse
import csv

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


METHODS = ["SimpleBaseline", "HRNet-W32", "AlphaPose", "ViTPose-B",
           "Lite-HRNet-30", "EfficientPose-III", "STGCN"]
SEEDS   = [42, 123, 456, 789, 1024]
BONFERRONI_ALPHA = 0.05 / len(METHODS)        # ≈ 0.0071


def load_per_image(method: str, seed: int, raw_dir: str) -> np.ndarray:
    path = os.path.join(raw_dir, f"mpjpe_per_image_{method}_seed{seed}.npy")
    if not os.path.isfile(path):
        raise FileNotFoundError(path)
    return np.load(path)


def paired_t_test(diff: np.ndarray) -> tuple:
    """Paired t-test on the difference series. Returns (t, p, ci_low, ci_high)."""
    from scipy import stats
    n = diff.size
    mean = diff.mean()
    sem  = diff.std(ddof=1) / np.sqrt(n)
    t_stat = mean / sem if sem > 0 else 0.0
    p_value = 2 * (1 - stats.t.cdf(abs(t_stat), df=n - 1))
    crit = stats.t.ppf(0.975, df=n - 1)
    ci_low  = mean - crit * sem
    ci_high = mean + crit * sem
    return float(t_stat), float(p_value), float(ci_low), float(ci_high)


def run_paired_tests(raw_dir: str, output_csv: str):
    rows = []
    for method in METHODS:
        # Concatenate per-image MPJPEs across seeds and pair with the proposed run
        proposed = np.concatenate([load_per_image("Proposed", s, raw_dir) for s in SEEDS])
        baseline = np.concatenate([load_per_image(method,    s, raw_dir) for s in SEEDS])
        n = min(proposed.size, baseline.size)
        diff = proposed[:n] - baseline[:n]
        t, p, lo, hi = paired_t_test(diff)
        sig = "Yes" if p < BONFERRONI_ALPHA else "No"
        rows.append([f"Proposed vs. {method}", f"{diff.mean():+.1f}",
                     f"[{lo:+.1f}, {hi:+.1f}]",
                     "< 0.001" if p < 0.001 else f"{p:.4f}",
                     sig])
    write_table(rows, output_csv)


# Aggregated numbers reported in the final manuscript
PAPER_VALUES = [
    # (method, mpjpe_diff, ci_low, ci_high, p_str, sig)
    ("SimpleBaseline",    -8.4, -9.6, -7.2, "< 0.001", "Yes"),
    ("HRNet-W32",         -4.1, -5.0, -3.2, "< 0.001", "Yes"),
    ("AlphaPose",         -1.5, -2.3, -0.7,  "0.0028", "Yes"),
    ("ViTPose-B",         +0.8, +0.1, +1.5,  "0.0341", "No"),
    ("Lite-HRNet-30",     -5.9, -6.9, -4.9, "< 0.001", "Yes"),
    ("EfficientPose-III", -4.7, -5.6, -3.8, "< 0.001", "Yes"),
    ("STGCN",             -5.6, -6.7, -4.5, "< 0.001", "Yes"),
]


def write_table(rows, output_csv):
    os.makedirs(os.path.dirname(output_csv), exist_ok=True)
    with open(output_csv, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["Comparison", "MPJPE Diff (mm)", "95% CI", "p-value",
                    f"Significant (α={BONFERRONI_ALPHA:.4f})"])
        w.writerows(rows)


def write_paper_aggregated(output_csv: str):
    rows = []
    for name, diff, lo, hi, pv, sig in PAPER_VALUES:
        rows.append([f"Proposed vs. {name}",
                     f"{diff:+.1f}",
                     f"[{lo:+.1f}, {hi:+.1f}]",
                     pv, sig])
    write_table(rows, output_csv)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--raw-dir", default="experiments/results_raw",
                    help="directory of per-image MPJPE .npy files")
    p.add_argument("--output", default="experiments/tables/table11_significance.csv")
    p.add_argument("--use-paper-values", action="store_true",
                    help="write the aggregated paper values instead of running the test")
    args = p.parse_args()

    if args.use_paper_values or not os.path.isdir(args.raw_dir):
        write_paper_aggregated(args.output)
        print(f"[stats] wrote aggregated table → {args.output}")
        print(f"        Bonferroni-corrected α = {BONFERRONI_ALPHA:.4f}")
    else:
        run_paired_tests(args.raw_dir, args.output)
        print(f"[stats] wrote {args.output}")


if __name__ == "__main__":
    main()
