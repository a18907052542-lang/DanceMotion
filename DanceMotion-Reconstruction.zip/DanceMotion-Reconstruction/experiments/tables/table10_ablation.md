| Configuration | MPJPE (mm) | PCK@0.5 (%) | Trajectory Jitter (px) | Frame Rate (fps) |
|---|---|---|---|---|
| Baseline Model | 53.2 | 85.1 | 4.7 | 45.2 |
| +Multi-scale Fusion | 48.5 | 88.3 | 4.2 | 38.6 |
| +Channel Attention | 46.3 | 89.7 | 3.8 | 36.1 |
| +Temporal Smoothing | 52.1 | 85.8 | 2.7 | 43.8 |
| Complete Method | 45.7 | 90.5 | 2.5 | 34.9 |
