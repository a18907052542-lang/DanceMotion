| Evaluation Dimension | Proposed Method | Best Comparison | Performance Diff. | Advantage Source Analysis |
|---|---|---|---|---|
| Detection Accuracy (MPJPE) | 45.7 mm | ViTPose-B: 44.9 mm | +1.80% | Reasonable cost of lightweight design |
| Keypoint Accuracy (PCK@0.5) | 90.5% | ViTPose-B: 91.2% | -0.80% | Limitations of feature fusion strategy |
| Average Precision (AP) | 76.8% | ViTPose-B: 77.1% | -0.40% | Overall performance basically equivalent |
| Inference Speed (fps) | 34.9 | STGCN: 56.8 | -38.60% | Computational overhead of end-to-end architecture |
| Model Parameters (M) | 26.8 | STGCN: 3.1 | +764% | Guarantee of feature extraction capability |
| Trajectory Smoothness (jitter/px) | 2.5 | STGCN: 2.1 | +19.00% | Close to specialized temporal model level |
| Speed-Accuracy Composite Score | 0.87 | HRNet-W32: 0.79 | +10.10% | Multi-module collaborative optimization effect |
