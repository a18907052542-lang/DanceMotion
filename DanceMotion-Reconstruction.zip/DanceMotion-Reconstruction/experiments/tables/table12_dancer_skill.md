| Dancer | Skill Level | Average Angular Velocity (°/s) | Motion Amplitude (px) | Left-Right Symmetry | Upper-Lower Limb Coordination | Beat Matching Degree |
|---|---|---|---|---|---|---|
| Dancer A | Professional | 156.3 | 342.8 | 0.94 | 2.31 | 0.93 |
| Dancer B | Professional | 148.7 | 328.5 | 0.92 | 2.18 | 0.91 |
| Dancer C | Intermediate | 132.4 | 298.6 | 0.85 | 1.87 | 0.84 |
| Dancer D | Amateur | 118.5 | 267.3 | 0.76 | 1.52 | 0.78 |
| Dancer E | Amateur | 109.2 | 245.1 | 0.71 | 1.38 | 0.72 |
