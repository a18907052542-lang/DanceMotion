| Limitation Dimension | Quantitative Observation | Primary Cause |
|---|---|---|
| Long-term self-occlusion | 42.3% of failure cases (street dance) | Motion model insufficient for highly non-linear acrobatic trajectories |
| Multi-person scenarios | MPJPE rises 47.9 / 53.4 / 58.6 mm (2/3/4 dancers) | Top-down strategy lacks identity association for dense crowds |
| Lighting variability | +16.1% MPJPE under saturated stage lights | Augmentation does not cover extreme stage-lighting cases |
| Camera viewpoint | Overhead / low-angle untested | Dataset covers only front / side views |
| Cross-dataset generalization | MPJPE 48.3 / 52.7 mm on H3.6M / Penn Action | Domain gap between dance and generic action data |
| Edge deployment | ~12–15 fps estimated on Jetson Nano | 26.8 M parameters exceed edge memory budget |
