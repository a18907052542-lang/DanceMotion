| Comparison | MPJPE Diff (mm) | 95% CI | p-value | Significant (α=0.0071) |
|---|---|---|---|---|
| Proposed vs. SimpleBaseline | -8.4 | [-9.6, -7.2] | < 0.001 | Yes |
| Proposed vs. HRNet-W32 | -4.1 | [-5.0, -3.2] | < 0.001 | Yes |
| Proposed vs. AlphaPose | -1.5 | [-2.3, -0.7] | 0.0028 | Yes |
| Proposed vs. ViTPose-B | +0.8 | [+0.1, +1.5] | 0.0341 | No |
| Proposed vs. Lite-HRNet-30 | -5.9 | [-6.9, -4.9] | < 0.001 | Yes |
| Proposed vs. EfficientPose-III | -4.7 | [-5.6, -3.8] | < 0.001 | Yes |
| Proposed vs. STGCN | -5.6 | [-6.7, -4.5] | < 0.001 | Yes |
