# -*- coding: utf-8 -*-
"""ResNet-50 backbone for pose estimation.

Outputs C2/C3/C4/C5 feature maps for FPN multi-scale fusion,
following Table 2 of the paper:
    Stage1 :  64 x 48,  256 ch
    Stage2 :  32 x 24,  512 ch
    Stage3 :  16 x 12, 1024 ch
    Stage4 :   8 x  6, 2048 ch
"""
import torch
import torch.nn as nn
from torchvision.models.resnet import Bottleneck


class ResNet50Backbone(nn.Module):
    """ResNet-50 backbone returning the four C2-C5 feature maps."""

    def __init__(self, pretrained: bool = True):
        super().__init__()
        # Stem (Conv1 in Table 2)
        self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        # Bottleneck stages (ResNet-50 layout: [3, 4, 6, 3])
        self.layer1 = self._make_layer(Bottleneck,  64, 64, blocks=3, stride=1)
        self.layer2 = self._make_layer(Bottleneck, 256, 128, blocks=4, stride=2)
        self.layer3 = self._make_layer(Bottleneck, 512, 256, blocks=6, stride=2)
        self.layer4 = self._make_layer(Bottleneck, 1024, 512, blocks=3, stride=2)

        self._init_weights()
        if pretrained:
            try:
                from torchvision.models import resnet50, ResNet50_Weights
                state = resnet50(weights=ResNet50_Weights.IMAGENET1K_V2).state_dict()
                # Strip the fc layer
                state = {k: v for k, v in state.items() if not k.startswith("fc.")}
                self.load_state_dict(state, strict=False)
            except Exception:
                pass

    def _make_layer(self, block, in_planes, planes, blocks: int, stride: int = 1):
        downsample = None
        if stride != 1 or in_planes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(in_planes, planes * block.expansion, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(planes * block.expansion),
            )

        layers = [block(in_planes, planes, stride=stride, downsample=downsample)]
        in_planes = planes * block.expansion
        for _ in range(1, blocks):
            layers.append(block(in_planes, planes))
        return nn.Sequential(*layers)

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1.0)
                nn.init.constant_(m.bias,   0.0)

    def forward(self, x: torch.Tensor):
        """Return [C2, C3, C4, C5] feature maps as defined in Table 2."""
        x = self.relu(self.bn1(self.conv1(x)))
        x = self.maxpool(x)
        c2 = self.layer1(x)
        c3 = self.layer2(c2)
        c4 = self.layer3(c3)
        c5 = self.layer4(c4)
        return [c2, c3, c4, c5]


if __name__ == "__main__":
    net = ResNet50Backbone(pretrained=False)
    x = torch.randn(1, 3, 256, 192)
    feats = net(x)
    for i, f in enumerate(feats, 2):
        print(f"C{i}: {tuple(f.shape)}")
