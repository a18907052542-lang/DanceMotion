# -*- coding: utf-8 -*-
"""Deconvolution head producing the 17-channel keypoint heatmaps.

Follows Table 2 of the paper:
    Deconvolution 1  : 128×96 ,  4×4 , stride 2 , 256 ch
    Deconvolution 2  : 256×192,  4×4 , stride 2 , 256 ch
    Output Layer     : 256×192,  1×1 , stride 1 ,  17 ch
"""
import torch
import torch.nn as nn


class DeconvHead(nn.Module):
    """Two-stage deconv head outputting 17 keypoint heatmaps at 256×192."""

    def __init__(self, in_channels: int = 256,
                 mid_channels: int = 256,
                 num_keypoints: int = 17):
        super().__init__()
        self.num_keypoints = num_keypoints

        # Deconv-1: 64×48  →  128×96
        self.deconv1 = nn.Sequential(
            nn.ConvTranspose2d(in_channels, mid_channels, kernel_size=4, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(mid_channels),
            nn.ReLU(inplace=True),
        )
        # Deconv-2: 128×96  →  256×192
        self.deconv2 = nn.Sequential(
            nn.ConvTranspose2d(mid_channels, mid_channels, kernel_size=4, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(mid_channels),
            nn.ReLU(inplace=True),
        )
        # Output 1×1 conv: → 17 heatmap channels
        self.output_conv = nn.Conv2d(mid_channels, num_keypoints, kernel_size=1, stride=1, padding=0)

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.ConvTranspose2d):
                nn.init.normal_(m.weight, std=0.001)
            elif isinstance(m, nn.Conv2d):
                nn.init.normal_(m.weight, std=0.001)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0.0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1.0)
                nn.init.constant_(m.bias,   0.0)

    def forward(self, f_att: torch.Tensor) -> torch.Tensor:
        """Produce 17-channel heatmaps from attention-weighted feature.

        Note: the network outputs heatmaps at the highest resolution (256×192)
        but training uses 64×48 ground-truth heatmaps to match the paper
        description (Eq. 4, σ_h = 2 px on the 64×48 grid). The eval-time
        downsample to 64×48 happens in the loss / decoder module.

        Args:
            f_att: (B, 256, 64, 48) attention-reweighted feature.
        Returns:
            heatmaps: (B, 17, 256, 192) keypoint heatmaps.
        """
        x = self.deconv1(f_att)
        x = self.deconv2(x)
        heatmaps = self.output_conv(x)
        return heatmaps


if __name__ == "__main__":
    head = DeconvHead()
    x = torch.randn(2, 256, 64, 48)
    h = head(x)
    print(f"Input  shape : {tuple(x.shape)}")
    print(f"Output shape : {tuple(h.shape)}  (expected: (2, 17, 256, 192))")
