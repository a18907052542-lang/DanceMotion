# -*- coding: utf-8 -*-
"""SimpleBaseline reference implementation for comparative experiments.

Architecture follows Xiao, Wu & Wei (ECCV 2018):
    ResNet-50 backbone → 3 deconvolution layers → 17-channel heatmap.

Used to reproduce the comparison row of Table 9 (MPJPE 54.1mm).
"""
import torch
import torch.nn as nn

from .._base import ResNetTrunk


class SimpleBaseline(nn.Module):
    def __init__(self, num_keypoints: int = 17, pretrained: bool = True):
        super().__init__()
        self.backbone = ResNetTrunk(arch="resnet50", pretrained=pretrained)

        # Three transposed convs (4×4, stride 2) → 256 channels each
        self.deconvs = nn.Sequential(
            nn.ConvTranspose2d(2048, 256, kernel_size=4, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(256), nn.ReLU(inplace=True),
            nn.ConvTranspose2d(256, 256, kernel_size=4, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(256), nn.ReLU(inplace=True),
            nn.ConvTranspose2d(256, 256, kernel_size=4, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(256), nn.ReLU(inplace=True),
        )
        self.final = nn.Conv2d(256, num_keypoints, kernel_size=1, stride=1, padding=0)
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, (nn.ConvTranspose2d, nn.Conv2d)):
                nn.init.normal_(m.weight, std=0.001)
                if getattr(m, "bias", None) is not None:
                    nn.init.constant_(m.bias, 0.0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1.0)
                nn.init.constant_(m.bias,   0.0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        feat = self.backbone(x)[-1]   # C5: 2048 × 8 × 6
        h = self.deconvs(feat)
        h = self.final(h)
        return h
