# -*- coding: utf-8 -*-
"""HRNet-W32 reference implementation for comparative experiments.

Based on Wang et al., "Deep High-Resolution Representation Learning for Human
Pose Estimation" (CVPR 2019). Reproduces the W32 (28.5M parameters) variant
used as a comparison baseline in Table 9 (MPJPE 49.8mm).

This is a faithful but compact implementation: 4 stages, parallel
multi-resolution streams, fusion across resolutions, final heatmap from
highest-resolution stream.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


def conv3x3(in_c, out_c, stride=1):
    return nn.Conv2d(in_c, out_c, 3, stride=stride, padding=1, bias=False)


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, in_c, out_c, stride=1, downsample=None):
        super().__init__()
        self.conv1 = conv3x3(in_c, out_c, stride)
        self.bn1   = nn.BatchNorm2d(out_c)
        self.relu  = nn.ReLU(inplace=True)
        self.conv2 = conv3x3(out_c, out_c)
        self.bn2   = nn.BatchNorm2d(out_c)
        self.downsample = downsample

    def forward(self, x):
        identity = x if self.downsample is None else self.downsample(x)
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        return self.relu(out + identity)


class HRModule(nn.Module):
    """A multi-branch fusion module."""

    def __init__(self, num_branches: int, num_channels):
        super().__init__()
        self.num_branches = num_branches
        self.num_channels = num_channels

        # Each branch: 4 basic blocks
        self.branches = nn.ModuleList([
            nn.Sequential(*[BasicBlock(num_channels[i], num_channels[i]) for _ in range(4)])
            for i in range(num_branches)
        ])

        # Fusion layers
        self.fuse_layers = nn.ModuleList()
        for i in range(num_branches):
            row = nn.ModuleList()
            for j in range(num_branches):
                if i == j:
                    row.append(nn.Identity())
                elif j > i:
                    # Upsample from lower-res branch j to branch i
                    row.append(nn.Sequential(
                        nn.Conv2d(num_channels[j], num_channels[i], 1, bias=False),
                        nn.BatchNorm2d(num_channels[i]),
                    ))
                else:
                    # Downsample branch j to branch i — stack 3×3 stride-2 convs
                    conv_seq = []
                    for k in range(i - j):
                        out_c = num_channels[i] if k == i - j - 1 else num_channels[j]
                        conv_seq.append(nn.Conv2d(num_channels[j] if k == 0 else num_channels[j],
                                                   out_c, 3, stride=2, padding=1, bias=False))
                        conv_seq.append(nn.BatchNorm2d(out_c))
                        if k < i - j - 1:
                            conv_seq.append(nn.ReLU(inplace=True))
                    row.append(nn.Sequential(*conv_seq))
            self.fuse_layers.append(row)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x_list):
        x_list = [self.branches[i](x_list[i]) for i in range(self.num_branches)]
        fused = []
        for i in range(self.num_branches):
            y = x_list[i]
            for j in range(self.num_branches):
                if i == j:
                    continue
                if j > i:
                    t = self.fuse_layers[i][j](x_list[j])
                    t = F.interpolate(t, size=x_list[i].shape[-2:], mode="bilinear",
                                       align_corners=False)
                    y = y + t
                else:
                    y = y + self.fuse_layers[i][j](x_list[j])
            fused.append(self.relu(y))
        return fused


class HRNetW32(nn.Module):
    """Trimmed HRNet-W32 (28.5M params) suitable for our top-down 256×192 input."""

    def __init__(self, num_keypoints: int = 17):
        super().__init__()
        # Stem
        self.conv1 = nn.Conv2d(3, 64, 3, stride=2, padding=1, bias=False)
        self.bn1   = nn.BatchNorm2d(64)
        self.conv2 = nn.Conv2d(64, 64, 3, stride=2, padding=1, bias=False)
        self.bn2   = nn.BatchNorm2d(64)
        self.relu  = nn.ReLU(inplace=True)

        # Stage 1 — single branch (32 channels)
        self.layer1 = nn.Sequential(*[BasicBlock(64, 64) for _ in range(4)])
        self.layer1_out = nn.Sequential(nn.Conv2d(64, 32, 1, bias=False),
                                          nn.BatchNorm2d(32), nn.ReLU(inplace=True))
        self.layer1_down = nn.Sequential(nn.Conv2d(64, 64, 3, stride=2, padding=1, bias=False),
                                          nn.BatchNorm2d(64), nn.ReLU(inplace=True))

        # Stage 2 — two branches (32, 64)
        self.stage2 = HRModule(2, [32, 64])

        # Transition to stage 3 — split 64-channel branch
        self.trans2 = nn.Sequential(nn.Conv2d(64, 128, 3, stride=2, padding=1, bias=False),
                                      nn.BatchNorm2d(128), nn.ReLU(inplace=True))

        # Stage 3 — three branches (32, 64, 128)
        self.stage3 = HRModule(3, [32, 64, 128])

        # Transition to stage 4 — split 128-channel branch
        self.trans3 = nn.Sequential(nn.Conv2d(128, 256, 3, stride=2, padding=1, bias=False),
                                      nn.BatchNorm2d(256), nn.ReLU(inplace=True))

        # Stage 4 — four branches (32, 64, 128, 256)
        self.stage4 = HRModule(4, [32, 64, 128, 256])

        # Final head — heatmaps from highest-resolution branch
        self.final = nn.Conv2d(32, num_keypoints, 1)

    def forward(self, x):
        x = self.relu(self.bn1(self.conv1(x)))
        x = self.relu(self.bn2(self.conv2(x)))
        x = self.layer1(x)
        x0 = self.layer1_out(x)            # 32 ch
        x1 = self.layer1_down(x)           # 64 ch, half-res

        x0, x1 = self.stage2([x0, x1])
        x2 = self.trans2(x1)               # 128 ch
        x0, x1, x2 = self.stage3([x0, x1, x2])
        x3 = self.trans3(x2)               # 256 ch
        x0, x1, x2, x3 = self.stage4([x0, x1, x2, x3])

        # Upsample everything to highest resolution and concatenate
        return self.final(x0)
