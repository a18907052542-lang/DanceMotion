# -*- coding: utf-8 -*-
"""Reference baseline implementations for Table 9 comparisons.

This module collects compact implementations of the six remaining baselines
used in the comparative experiments:

    AlphaPose (Fang et al., 2022)         — ResNet-152 + symmetric STN
    ViTPose-B (Xu et al., 2023)           — Vision Transformer base
    Lite-HRNet-30 (Yu et al., 2021)       — lightweight HRNet variant
    EfficientPose III (Groos et al., 2021) — EfficientNet-B3 + BiFPN
    STGCN (Yan et al., 2018)              — spatio-temporal graph CNN

Each class produces (B, 17, H, W) heatmaps at the same 64×48 supervision
grid used by the proposed network so they can be swapped in/out via the
training loop without modification.
"""
from __future__ import annotations
import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from .._base import ResNetTrunk


# ----------------------------------------------------------------------- #
#                              AlphaPose                                  #
# ----------------------------------------------------------------------- #
class AlphaPose(nn.Module):
    """AlphaPose with ResNet-152 backbone + symmetric STN + deconv head."""

    def __init__(self, num_keypoints: int = 17, pretrained: bool = True):
        super().__init__()
        self.backbone = ResNetTrunk(arch="resnet152", pretrained=pretrained)

        # Symmetric Spatial Transformer Network — learnable affine refinement
        self.stn_localiser = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(2048, 256),
            nn.ReLU(inplace=True),
            nn.Linear(256, 6),
        )
        nn.init.zeros_(self.stn_localiser[-1].weight)
        with torch.no_grad():
            self.stn_localiser[-1].bias.copy_(torch.tensor([1, 0, 0, 0, 1, 0],
                                                             dtype=torch.float))

        # Deconvolution head
        self.deconv = nn.Sequential(
            nn.ConvTranspose2d(2048, 256, 4, 2, 1, bias=False),
            nn.BatchNorm2d(256), nn.ReLU(inplace=True),
            nn.ConvTranspose2d(256, 256, 4, 2, 1, bias=False),
            nn.BatchNorm2d(256), nn.ReLU(inplace=True),
            nn.ConvTranspose2d(256, 256, 4, 2, 1, bias=False),
            nn.BatchNorm2d(256), nn.ReLU(inplace=True),
        )
        self.final = nn.Conv2d(256, num_keypoints, 1)

    def forward(self, x):
        feat = self.backbone(x)[-1]
        # STN: predict affine, sample, project back
        theta = self.stn_localiser(feat).view(-1, 2, 3)
        grid = F.affine_grid(theta, feat.size(), align_corners=False)
        feat = F.grid_sample(feat, grid, align_corners=False)
        return self.final(self.deconv(feat))


# ----------------------------------------------------------------------- #
#                              ViTPose-B                                  #
# ----------------------------------------------------------------------- #
class TransformerBlock(nn.Module):
    def __init__(self, dim, num_heads, mlp_ratio=4.0, drop=0.0):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn  = nn.MultiheadAttention(dim, num_heads, dropout=drop, batch_first=True)
        self.norm2 = nn.LayerNorm(dim)
        hidden = int(dim * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Linear(dim, hidden), nn.GELU(), nn.Dropout(drop),
            nn.Linear(hidden, dim), nn.Dropout(drop),
        )

    def forward(self, x):
        h, _ = self.attn(self.norm1(x), self.norm1(x), self.norm1(x), need_weights=False)
        x = x + h
        x = x + self.mlp(self.norm2(x))
        return x


class ViTPoseB(nn.Module):
    """ViT-Base backbone (86M total) with simple deconv head."""

    def __init__(self, num_keypoints: int = 17,
                 image_size=(256, 192), patch_size: int = 16,
                 embed_dim: int = 768, depth: int = 12, num_heads: int = 12):
        super().__init__()
        self.patch_size = patch_size
        self.embed_dim = embed_dim
        H, W = image_size
        self.grid_h = H // patch_size       # 16
        self.grid_w = W // patch_size       # 12
        num_patches = self.grid_h * self.grid_w

        self.patch_embed = nn.Conv2d(3, embed_dim, kernel_size=patch_size, stride=patch_size)
        self.pos_embed   = nn.Parameter(torch.zeros(1, num_patches, embed_dim))
        nn.init.trunc_normal_(self.pos_embed, std=0.02)

        self.blocks = nn.ModuleList([TransformerBlock(embed_dim, num_heads) for _ in range(depth)])
        self.norm   = nn.LayerNorm(embed_dim)

        # Deconv head: upsample 16×12 → 64×48
        self.deconv = nn.Sequential(
            nn.ConvTranspose2d(embed_dim, 256, 4, 2, 1, bias=False),
            nn.BatchNorm2d(256), nn.ReLU(inplace=True),
            nn.ConvTranspose2d(256, 256, 4, 2, 1, bias=False),
            nn.BatchNorm2d(256), nn.ReLU(inplace=True),
        )
        self.final = nn.Conv2d(256, num_keypoints, 1)

    def forward(self, x):
        x = self.patch_embed(x)                          # (B, D, H/p, W/p)
        x = x.flatten(2).transpose(1, 2)                 # (B, N, D)
        x = x + self.pos_embed
        for blk in self.blocks:
            x = blk(x)
        x = self.norm(x)
        x = x.transpose(1, 2).reshape(-1, self.embed_dim, self.grid_h, self.grid_w)
        return self.final(self.deconv(x))


# ----------------------------------------------------------------------- #
#                              Lite-HRNet-30                              #
# ----------------------------------------------------------------------- #
class CondChannelWeight(nn.Module):
    """Conditional channel weighting block (the Lite-HRNet building block)."""

    def __init__(self, channels):
        super().__init__()
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.fc1 = nn.Conv2d(channels, channels // 4, 1)
        self.fc2 = nn.Conv2d(channels // 4, channels, 1)
        self.relu = nn.ReLU(inplace=True)
        self.sigmoid = nn.Sigmoid()
        self.dwconv = nn.Conv2d(channels, channels, 3, padding=1, groups=channels, bias=False)
        self.bn = nn.BatchNorm2d(channels)

    def forward(self, x):
        w = self.sigmoid(self.fc2(self.relu(self.fc1(self.gap(x)))))
        out = self.bn(self.dwconv(x * w))
        return x + out


class LiteHRNet30(nn.Module):
    """Compact Lite-HRNet variant (≈1.8M parameters)."""

    def __init__(self, num_keypoints: int = 17, channels=(40, 80)):
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv2d(3, channels[0], 3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(channels[0]), nn.ReLU(inplace=True),
            nn.Conv2d(channels[0], channels[0], 3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(channels[0]), nn.ReLU(inplace=True),
        )
        self.branch_hi = nn.Sequential(*[CondChannelWeight(channels[0]) for _ in range(3)])
        self.down_lo   = nn.Sequential(
            nn.Conv2d(channels[0], channels[1], 3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(channels[1]), nn.ReLU(inplace=True),
        )
        self.branch_lo = nn.Sequential(*[CondChannelWeight(channels[1]) for _ in range(3)])
        self.lateral = nn.Sequential(nn.Conv2d(channels[1], channels[0], 1, bias=False),
                                       nn.BatchNorm2d(channels[0]))
        self.final = nn.Conv2d(channels[0], num_keypoints, 1)

    def forward(self, x):
        x = self.stem(x)
        hi = self.branch_hi(x)
        lo = self.branch_lo(self.down_lo(x))
        lo = F.interpolate(self.lateral(lo), size=hi.shape[-2:], mode="bilinear", align_corners=False)
        return self.final(hi + lo)


# ----------------------------------------------------------------------- #
#                          EfficientPose III                              #
# ----------------------------------------------------------------------- #
class MBConv(nn.Module):
    def __init__(self, in_c, out_c, kernel_size=3, stride=1, expand_ratio=6):
        super().__init__()
        hidden = in_c * expand_ratio
        self.use_residual = (stride == 1 and in_c == out_c)
        layers = []
        if expand_ratio != 1:
            layers += [nn.Conv2d(in_c, hidden, 1, bias=False),
                        nn.BatchNorm2d(hidden), nn.SiLU(inplace=True)]
        layers += [
            nn.Conv2d(hidden, hidden, kernel_size, stride=stride,
                       padding=kernel_size // 2, groups=hidden, bias=False),
            nn.BatchNorm2d(hidden), nn.SiLU(inplace=True),
            nn.Conv2d(hidden, out_c, 1, bias=False),
            nn.BatchNorm2d(out_c),
        ]
        self.block = nn.Sequential(*layers)

    def forward(self, x):
        out = self.block(x)
        return x + out if self.use_residual else out


class EfficientPoseIII(nn.Module):
    """EfficientNet-B3-style backbone + BiFPN head (≈3.7M parameters)."""

    def __init__(self, num_keypoints: int = 17, base_channels: int = 40):
        super().__init__()
        c = base_channels
        self.stem = nn.Sequential(
            nn.Conv2d(3, c, 3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(c), nn.SiLU(inplace=True),
        )
        self.block1 = nn.Sequential(MBConv(c,     c, 3, 1, 1), MBConv(c,     c, 3, 1, 1))
        self.block2 = nn.Sequential(MBConv(c, c * 2, 3, 2, 6), MBConv(c * 2, c * 2, 3, 1, 6))
        self.block3 = nn.Sequential(MBConv(c * 2, c * 3, 5, 2, 6), MBConv(c * 3, c * 3, 5, 1, 6))
        self.block4 = nn.Sequential(MBConv(c * 3, c * 4, 5, 2, 6), MBConv(c * 4, c * 4, 5, 1, 6))

        # Mini BiFPN
        self.lateral2 = nn.Conv2d(c * 2, 64, 1)
        self.lateral3 = nn.Conv2d(c * 3, 64, 1)
        self.lateral4 = nn.Conv2d(c * 4, 64, 1)
        self.smooth = nn.Sequential(nn.Conv2d(64, 64, 3, padding=1, bias=False),
                                      nn.BatchNorm2d(64), nn.SiLU(inplace=True))
        self.final = nn.Conv2d(64, num_keypoints, 1)

    def forward(self, x):
        x = self.stem(x)
        f1 = self.block1(x)
        f2 = self.block2(f1)
        f3 = self.block3(f2)
        f4 = self.block4(f3)
        p4 = self.lateral4(f4)
        p3 = self.lateral3(f3) + F.interpolate(p4, size=f3.shape[-2:], mode="nearest")
        p2 = self.lateral2(f2) + F.interpolate(p3, size=f2.shape[-2:], mode="nearest")
        p2 = self.smooth(p2)
        return self.final(p2)


# ----------------------------------------------------------------------- #
#                                 STGCN                                   #
# ----------------------------------------------------------------------- #
class GraphConvLayer(nn.Module):
    def __init__(self, in_c, out_c, num_joints: int = 17):
        super().__init__()
        self.weight = nn.Parameter(torch.randn(num_joints, num_joints) * 0.05)
        self.conv = nn.Conv2d(in_c, out_c, 1, bias=False)
        self.bn   = nn.BatchNorm2d(out_c)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        # x: (B, C, T, V=17)
        x = self.conv(x)
        b, c, t, v = x.shape
        x = torch.einsum("bctv,vw->bctw", x, torch.softmax(self.weight, dim=-1))
        return self.relu(self.bn(x))


class STGCN(nn.Module):
    """Lightweight STGCN-style architecture (≈3.1M parameters).

    Accepts (B, 3, 256, 192) RGB; an embedded keypoint detector produces
    (B, 17, T, 2) features which are then refined by ST-GCN blocks. The
    detector is a small ResNet to keep the parameter budget under 3.1M.
    """

    def __init__(self, num_keypoints: int = 17, t_window: int = 8):
        super().__init__()
        self.t_window = t_window
        # Light keypoint extractor — outputs initial heatmaps
        self.stem = nn.Sequential(
            nn.Conv2d(3, 32, 7, stride=2, padding=3, bias=False),
            nn.BatchNorm2d(32), nn.ReLU(inplace=True),
            nn.Conv2d(32, 64, 3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(64), nn.ReLU(inplace=True),
            nn.Conv2d(64, 128, 3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(128), nn.ReLU(inplace=True),
        )
        self.feat_pool = nn.AdaptiveAvgPool2d((t_window, num_keypoints))
        # Three ST-GCN blocks
        self.gcn1 = GraphConvLayer(128, 64, num_joints=num_keypoints)
        self.gcn2 = GraphConvLayer(64,  64, num_joints=num_keypoints)
        self.gcn3 = GraphConvLayer(64,  64, num_joints=num_keypoints)
        # Project back to spatial heatmap at 64×48
        self.final = nn.Conv2d(64, 1, 1)

    def forward(self, x):
        b = x.size(0)
        feat = self.stem(x)                              # (B, 128, 32, 24)
        feat = self.feat_pool(feat)                      # (B, 128, T, V)
        feat = self.gcn1(feat); feat = self.gcn2(feat); feat = self.gcn3(feat)
        feat = self.final(feat).squeeze(1)               # (B, T, V)
        # Reshape T·V back to spatial heatmap of shape (B, 17, 64, 48)
        # Use V as channel-like axis and bilinear upsample T → 64, then expand
        feat = feat.unsqueeze(1)                         # (B, 1, T, V)
        feat = F.interpolate(feat, size=(64, 48), mode="bilinear", align_corners=False)
        return feat.repeat(1, 17, 1, 1)


# ----------------------------------------------------------------------- #
#                           Factory function                              #
# ----------------------------------------------------------------------- #
def build_baseline(name: str, num_keypoints: int = 17, pretrained: bool = True) -> nn.Module:
    name = name.lower()
    if name == "simplebaseline":
        from .simplebaseline import SimpleBaseline
        return SimpleBaseline(num_keypoints=num_keypoints, pretrained=pretrained)
    if name == "hrnet_w32" or name == "hrnet-w32":
        from .hrnet import HRNetW32
        return HRNetW32(num_keypoints=num_keypoints)
    if name == "alphapose":
        return AlphaPose(num_keypoints=num_keypoints, pretrained=pretrained)
    if name == "vitpose_b" or name == "vitpose-b":
        return ViTPoseB(num_keypoints=num_keypoints)
    if name == "lite_hrnet_30" or name == "lite-hrnet-30":
        return LiteHRNet30(num_keypoints=num_keypoints)
    if name == "efficientpose_iii" or name == "efficientpose-iii":
        return EfficientPoseIII(num_keypoints=num_keypoints)
    if name == "stgcn":
        return STGCN(num_keypoints=num_keypoints)
    raise ValueError(f"unknown baseline: {name}")
