# -*- coding: utf-8 -*-
"""Channel attention module.

Implements Eq. (2)-(3) of the paper:
    A_c    = σ( W2 · ReLU( W1 · GAP(F_fuse) ) )       (Eq. 2)
    F_att  = A_c ⊙ F_fuse                              (Eq. 3)

W1 ∈ R^{(C/r)×C}, W2 ∈ R^{C×(C/r)}, σ = Sigmoid,
⊙ = element-wise multiplication (broadcast along H, W).
C = 256, r = 16 (channel compression ratio).
"""
import torch
import torch.nn as nn


class ChannelAttention(nn.Module):
    """SE-style channel attention (Eq. 2-3) with reduction ratio r=16."""

    def __init__(self, channels: int = 256, reduction_ratio: int = 16):
        super().__init__()
        self.channels = channels
        self.reduction_ratio = reduction_ratio
        reduced = max(1, channels // reduction_ratio)

        # Global average pooling (Eq. 2: GAP(F_fuse))
        self.gap = nn.AdaptiveAvgPool2d(1)

        # W1 ∈ R^{(C/r)×C} and W2 ∈ R^{C×(C/r)}
        self.fc1 = nn.Linear(channels, reduced, bias=True)
        self.fc2 = nn.Linear(reduced, channels, bias=True)
        self.relu = nn.ReLU(inplace=True)
        self.sigmoid = nn.Sigmoid()

        # Kaiming init for the two fully-connected layers
        nn.init.kaiming_normal_(self.fc1.weight, mode="fan_out", nonlinearity="relu")
        nn.init.constant_(self.fc1.bias, 0.0)
        nn.init.kaiming_normal_(self.fc2.weight, mode="fan_out", nonlinearity="sigmoid")
        nn.init.constant_(self.fc2.bias, 0.0)

    def forward(self, f_fuse: torch.Tensor) -> torch.Tensor:
        """Apply channel attention to the fused feature map.

        Args:
            f_fuse: (B, C, H, W) fused feature map.
        Returns:
            f_att:  (B, C, H, W) attention-reweighted feature map.
        """
        b, c, h, w = f_fuse.shape

        # Eq. 2: GAP → C-dim descriptor → W1 + ReLU → W2 → σ
        z = self.gap(f_fuse).view(b, c)                # GAP(F_fuse) → R^{B×C}
        z = self.relu(self.fc1(z))                     # W1·z
        z = self.sigmoid(self.fc2(z))                  # σ(W2·…)

        # Reshape to broadcast over H,W and apply element-wise multiplication (Eq. 3)
        a_c = z.view(b, c, 1, 1)
        f_att = a_c * f_fuse
        return f_att, a_c


if __name__ == "__main__":
    att = ChannelAttention(channels=256, reduction_ratio=16)
    x = torch.randn(2, 256, 64, 48)
    y, ac = att(x)
    print(f"Input  shape : {tuple(x.shape)}")
    print(f"Output shape : {tuple(y.shape)}")
    print(f"A_c    shape : {tuple(ac.shape)}  (expected: (2, 256, 1, 1))")
    print(f"A_c    range : [{ac.min().item():.4f}, {ac.max().item():.4f}]")
