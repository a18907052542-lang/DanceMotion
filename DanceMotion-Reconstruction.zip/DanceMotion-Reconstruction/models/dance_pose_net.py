# -*- coding: utf-8 -*-
"""Top-level dance pose estimation network.

Integrates the four components defined in Section 3.2 of the paper:
    (1) ResNet-50 backbone                           (Table 2, Conv1-Stage4)
    (2) FPN multi-scale fusion (Eq. 1)               → 256 × 64 × 48
    (3) SE-style channel attention (Eq. 2-3, r=16)   → 256 × 64 × 48
    (4) Deconv head outputting 17 heatmaps           (Table 2)

Total parameter count is 26.8M (consistent with Table 1).
"""
import torch
import torch.nn as nn

from .backbone import ResNet50Backbone
from .fpn_fusion import FPNFusion
from .channel_attention import ChannelAttention
from .deconv_head import DeconvHead


class DancePoseNet(nn.Module):
    """End-to-end pose estimation network described in Section 3.2."""

    def __init__(self,
                 num_keypoints: int = 17,
                 width_multiplier: float = 1.0,
                 backbone_pretrained: bool = True,
                 attention_reduction_ratio: int = 16):
        super().__init__()
        self.num_keypoints = num_keypoints
        self.width_multiplier = width_multiplier

        # Backbone
        self.backbone = ResNet50Backbone(pretrained=backbone_pretrained)
        backbone_channels = [int(c * width_multiplier) for c in (256, 512, 1024, 2048)]

        # FPN multi-scale fusion (Eq. 1) → 256 channels at 64×48
        fpn_out_channels = int(256 * width_multiplier)
        self.fpn = FPNFusion(in_channels_list=tuple(backbone_channels),
                             out_channels=fpn_out_channels,
                             target_size=(64, 48))

        # Channel attention (Eq. 2-3) with r=16
        self.attention = ChannelAttention(channels=fpn_out_channels,
                                          reduction_ratio=attention_reduction_ratio)

        # Deconv head → 17 keypoint heatmaps at 256×192
        self.head = DeconvHead(in_channels=fpn_out_channels,
                               mid_channels=fpn_out_channels,
                               num_keypoints=num_keypoints)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass.

        Args:
            x: (B, 3, 256, 192) RGB image tensor.
        Returns:
            heatmaps: (B, 17, 256, 192) keypoint heatmaps.
        """
        feats = self.backbone(x)              # [C2, C3, C4, C5]
        f_fuse = self.fpn(feats)              # (B, 256, 64, 48) — Eq. 1
        f_att, _ = self.attention(f_fuse)     # (B, 256, 64, 48) — Eq. 2-3
        heatmaps = self.head(f_att)           # (B, 17, 256, 192)
        return heatmaps

    def count_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

    def get_components(self):
        return {
            "backbone": self.backbone,
            "fpn":      self.fpn,
            "attention": self.attention,
            "head":      self.head,
        }


def build_model(config: dict = None) -> DancePoseNet:
    """Build the pose estimation network from a config dict."""
    config = config or {}
    return DancePoseNet(
        num_keypoints=config.get("num_keypoints", 17),
        width_multiplier=config.get("width_multiplier", 1.0),
        backbone_pretrained=config.get("backbone_pretrained", True),
        attention_reduction_ratio=config.get("attention_reduction_ratio", 16),
    )


if __name__ == "__main__":
    net = build_model({"backbone_pretrained": False})
    n_params = net.count_parameters() / 1e6
    print(f"DancePoseNet parameters : {n_params:.1f} M  (paper: 26.8 M)")
    x = torch.randn(1, 3, 256, 192)
    h = net(x)
    print(f"Output heatmaps shape   : {tuple(h.shape)}")
