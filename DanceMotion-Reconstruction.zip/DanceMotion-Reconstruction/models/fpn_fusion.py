# -*- coding: utf-8 -*-
"""Multi-scale feature pyramid fusion module.

Implements Eq. (1) of the paper:
    F_fuse = Σ_{i=1..4} w_i · Up(F_i, s_i)

where F_i comes from the i-th backbone stage, Up(·, s_i) is bilinear
upsampling with scale factor s_i ∈ {1, 2, 4, 8}, and w_i are learnable
fusion weights normalized via softmax (Σ w_i = 1). All maps are
projected to 256 channels and resampled to 64×48 before fusion.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class FPNFusion(nn.Module):
    """Multi-scale FPN fusion producing the 256×64×48 fused feature map."""

    def __init__(self, in_channels_list=(256, 512, 1024, 2048),
                 out_channels: int = 256,
                 target_size=(64, 48)):
        super().__init__()
        self.target_size = target_size
        # 1×1 lateral projections (Table 2: "FPN Fusion  64×48  1×1  256")
        self.lateral_convs = nn.ModuleList([
            nn.Conv2d(c_in, out_channels, kernel_size=1, stride=1, bias=False)
            for c_in in in_channels_list
        ])
        self.lateral_bns = nn.ModuleList([nn.BatchNorm2d(out_channels) for _ in in_channels_list])

        # Learnable fusion weights w_i (normalized via softmax)
        self.fusion_weights = nn.Parameter(torch.ones(len(in_channels_list)))

        # Light post-fusion smoothing 3×3 conv
        self.smooth = nn.Sequential(
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, feats):
        """Forward pass.

        Args:
            feats: list of four feature maps [C2, C3, C4, C5] from the backbone.
        Returns:
            F_fuse: tensor of shape (B, 256, 64, 48).
        """
        assert len(feats) == len(self.lateral_convs)

        projected = []
        for f, lat, bn in zip(feats, self.lateral_convs, self.lateral_bns):
            p = lat(f)
            p = bn(p)
            # Resample every level to target 64×48
            if p.shape[-2:] != self.target_size:
                p = F.interpolate(p, size=self.target_size, mode="bilinear", align_corners=False)
            projected.append(p)

        # Softmax-normalized fusion weights (Σ w_i = 1)
        w = torch.softmax(self.fusion_weights, dim=0)
        f_fuse = sum(w[i] * projected[i] for i in range(len(projected)))
        f_fuse = self.smooth(f_fuse)
        return f_fuse


if __name__ == "__main__":
    fpn = FPNFusion()
    feats = [torch.randn(2, c, h, w) for c, h, w in
             [(256, 64, 48), (512, 32, 24), (1024, 16, 12), (2048, 8, 6)]]
    out = fpn(feats)
    print(f"FPN output: {tuple(out.shape)}  (expected: (2, 256, 64, 48))")
    print(f"Fusion weights (softmax-normalized): {torch.softmax(fpn.fusion_weights, dim=0).detach()}")
