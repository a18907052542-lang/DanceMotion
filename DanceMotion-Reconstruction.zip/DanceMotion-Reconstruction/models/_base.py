# -*- coding: utf-8 -*-
"""Shared backbone trunk used by reference baseline implementations."""
import torch.nn as nn
from torchvision.models import resnet50, resnet152
try:
    from torchvision.models import ResNet50_Weights, ResNet152_Weights
    _HAS_WEIGHT_ENUM = True
except ImportError:
    _HAS_WEIGHT_ENUM = False


class ResNetTrunk(nn.Module):
    """Returns the four C2-C5 feature maps from a torchvision ResNet."""

    def __init__(self, arch: str = "resnet50", pretrained: bool = True):
        super().__init__()
        if arch == "resnet50":
            if _HAS_WEIGHT_ENUM and pretrained:
                net = resnet50(weights=ResNet50_Weights.IMAGENET1K_V2)
            else:
                net = resnet50(weights=None)
        elif arch == "resnet152":
            if _HAS_WEIGHT_ENUM and pretrained:
                net = resnet152(weights=ResNet152_Weights.IMAGENET1K_V2)
            else:
                net = resnet152(weights=None)
        else:
            raise ValueError(f"unknown arch {arch}")

        self.conv1   = net.conv1
        self.bn1     = net.bn1
        self.relu    = net.relu
        self.maxpool = net.maxpool
        self.layer1  = net.layer1
        self.layer2  = net.layer2
        self.layer3  = net.layer3
        self.layer4  = net.layer4

    def forward(self, x):
        x = self.relu(self.bn1(self.conv1(x)))
        x = self.maxpool(x)
        c2 = self.layer1(x)
        c3 = self.layer2(c2)
        c4 = self.layer3(c3)
        c5 = self.layer4(c4)
        return [c2, c3, c4, c5]
