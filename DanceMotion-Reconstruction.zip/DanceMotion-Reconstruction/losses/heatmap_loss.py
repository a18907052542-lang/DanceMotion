# -*- coding: utf-8 -*-
"""Heatmap mean-squared-error loss.

Implements Eq. (4) of the paper:
    L_heatmap = (1/K) * Σ_{k=1..K} || H_k^pred - H_k^gt ||_2^2

with K = 17 (COCO keypoints) and H ∈ R^{64×48}. Ground-truth heatmaps
are produced by placing a 2-D Gaussian with σ_h = 2 px at each
annotated keypoint location.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class HeatmapMSELoss(nn.Module):
    """Per-keypoint MSE loss with optional visibility/weight masking."""

    def __init__(self, num_keypoints: int = 17,
                 use_target_weight: bool = True,
                 target_size=(64, 48)):
        super().__init__()
        self.num_keypoints = num_keypoints
        self.use_target_weight = use_target_weight
        self.target_size = target_size
        # We sum-then-divide-by-K manually (cf. Eq. 4); MSE per-element under-the-hood.
        self.criterion = nn.MSELoss(reduction="mean")

    def forward(self,
                pred_heatmaps: torch.Tensor,
                gt_heatmaps:   torch.Tensor,
                target_weight: torch.Tensor = None) -> torch.Tensor:
        """Compute heatmap MSE loss (Eq. 4).

        Args:
            pred_heatmaps: (B, K, H_p, W_p) network output.
            gt_heatmaps  : (B, K, 64, 48)   ground-truth heatmaps.
            target_weight: (B, K) optional per-keypoint visibility weight.
        Returns:
            scalar loss tensor.
        """
        # Resample predictions to the 64×48 GT grid (Eq. 4 lives at this scale)
        if pred_heatmaps.shape[-2:] != self.target_size:
            pred_heatmaps = F.interpolate(
                pred_heatmaps, size=self.target_size,
                mode="bilinear", align_corners=False,
            )

        b, k = pred_heatmaps.shape[:2]
        pred_flat = pred_heatmaps.reshape(b, k, -1)
        gt_flat   = gt_heatmaps.reshape(b, k, -1)

        loss = 0.0
        for j in range(k):
            p_j = pred_flat[:, j]
            g_j = gt_flat[:, j]
            if self.use_target_weight and target_weight is not None:
                w = target_weight[:, j].unsqueeze(1)   # (B, 1)
                loss = loss + 0.5 * self.criterion(p_j * w, g_j * w)
            else:
                loss = loss + 0.5 * self.criterion(p_j, g_j)
        return loss / k


def generate_target_heatmap(joints_xy: torch.Tensor,
                             joints_vis: torch.Tensor,
                             image_size=(256, 192),
                             heatmap_size=(64, 48),
                             sigma_h: float = 2.0) -> tuple:
    """Generate ground-truth 64×48 heatmaps from joint coordinates.

    Args:
        joints_xy:  (B, K, 2) pixel coordinates in the input image frame.
        joints_vis: (B, K) visibility flags (0=invisible, 1=occluded, 2=visible).
        image_size:  (H, W) of the input image (paper: 256×192).
        heatmap_size: (H, W) of the output heatmap (paper: 64×48).
        sigma_h: Gaussian standard deviation in pixels at the heatmap scale.

    Returns:
        target:        (B, K, 64, 48) heatmap tensor.
        target_weight: (B, K) per-keypoint visibility weight.
    """
    b, k = joints_xy.shape[:2]
    H_t, W_t = heatmap_size
    H_i, W_i = image_size
    feat_stride_x = W_i / W_t
    feat_stride_y = H_i / H_t

    target = torch.zeros((b, k, H_t, W_t), dtype=torch.float32, device=joints_xy.device)
    target_weight = (joints_vis > 0).float()        # treat occluded+visible as supervised

    # Pre-compute the 2D Gaussian kernel patch
    tmp_size = int(3 * sigma_h)
    size = 2 * tmp_size + 1
    yy, xx = torch.meshgrid(
        torch.arange(size, device=joints_xy.device),
        torch.arange(size, device=joints_xy.device),
        indexing="ij",
    )
    g = torch.exp(-((xx - tmp_size) ** 2 + (yy - tmp_size) ** 2) / (2 * sigma_h ** 2))

    for n in range(b):
        for j in range(k):
            if target_weight[n, j] < 0.5:
                continue
            mu_x = int(joints_xy[n, j, 0].item() / feat_stride_x + 0.5)
            mu_y = int(joints_xy[n, j, 1].item() / feat_stride_y + 0.5)

            ul = (mu_x - tmp_size, mu_y - tmp_size)
            br = (mu_x + tmp_size + 1, mu_y + tmp_size + 1)
            if ul[0] >= W_t or ul[1] >= H_t or br[0] < 0 or br[1] < 0:
                target_weight[n, j] = 0
                continue

            g_x = max(0, -ul[0]), min(br[0], W_t) - ul[0]
            g_y = max(0, -ul[1]), min(br[1], H_t) - ul[1]
            img_x = max(0, ul[0]), min(br[0], W_t)
            img_y = max(0, ul[1]), min(br[1], H_t)
            target[n, j, img_y[0]:img_y[1], img_x[0]:img_x[1]] = \
                g[g_y[0]:g_y[1], g_x[0]:g_x[1]]

    return target, target_weight


if __name__ == "__main__":
    torch.manual_seed(0)
    pred = torch.randn(2, 17, 64, 48)
    joints = torch.rand(2, 17, 2) * torch.tensor([192.0, 256.0])
    vis = torch.full((2, 17), 2.0)
    gt, w = generate_target_heatmap(joints, vis)
    loss_fn = HeatmapMSELoss()
    loss = loss_fn(pred, gt, w)
    print(f"GT heatmap shape : {tuple(gt.shape)}")
    print(f"Loss value       : {loss.item():.6f}")
