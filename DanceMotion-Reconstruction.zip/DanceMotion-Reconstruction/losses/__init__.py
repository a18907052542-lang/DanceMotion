# -*- coding: utf-8 -*-
"""Loss functions for the DanceMotion-2024 pose estimation network."""
from .heatmap_loss import HeatmapMSELoss, generate_target_heatmap
__all__ = ["HeatmapMSELoss", "generate_target_heatmap"]
