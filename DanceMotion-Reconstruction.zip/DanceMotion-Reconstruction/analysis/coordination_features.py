# -*- coding: utf-8 -*-
"""Coordination feature extraction.

Implements the coordination metrics described in Section 3.4:

    1. Left-Right Symmetry (LRS):
           Pearson correlation between mirrored joints' trajectories,
           averaged over (shoulder, elbow, wrist, hip, knee, ankle).
    2. Upper-Lower Limb Coordination (UL-LL):
           Mutual information between discretised upper-limb and
           lower-limb motion states (Eq. 9):

               I(L; R) = Σ_l Σ_r p(l,r) · log( p(l,r) / (p(l) p(r)) )
"""
from __future__ import annotations
import numpy as np


# Mirror joint pairs (left ↔ right)
MIRROR_PAIRS = [
    (5, 6),    # shoulders
    (7, 8),    # elbows
    (9, 10),   # wrists
    (11, 12),  # hips
    (13, 14),  # knees
    (15, 16),  # ankles
]

# Upper / lower limb joint groups
UPPER_LIMB_IDX = [5, 6, 7, 8, 9, 10]
LOWER_LIMB_IDX = [11, 12, 13, 14, 15, 16]


def pearson_corr(x: np.ndarray, y: np.ndarray) -> float:
    """Pearson correlation coefficient between two 1-D series."""
    x = x - x.mean()
    y = y - y.mean()
    denom = np.sqrt(np.sum(x ** 2) * np.sum(y ** 2)) + 1e-12
    return float(np.sum(x * y) / denom)


def left_right_symmetry(keypoint_seq: np.ndarray) -> float:
    """Average mirrored-joint trajectory correlation, in [-1, 1].

    For each (L, R) mirror pair we compute Pearson correlation between
    the X-axis trajectory of the left joint and the mirrored X-axis
    trajectory of the right joint (using image centre as the mirror line).
    """
    img_centre_x = float(keypoint_seq[:, :, 0].mean())
    corrs = []
    for l_idx, r_idx in MIRROR_PAIRS:
        x_left  = keypoint_seq[:, l_idx, 0] - img_centre_x
        x_right = -(keypoint_seq[:, r_idx, 0] - img_centre_x)  # mirror about centre
        y_left  = keypoint_seq[:, l_idx, 1]
        y_right = keypoint_seq[:, r_idx, 1]
        c_x = pearson_corr(x_left, x_right)
        c_y = pearson_corr(y_left, y_right)
        corrs.append((c_x + c_y) / 2.0)
    return float(np.mean(corrs))


def _discretize(series: np.ndarray, n_bins: int = 8) -> np.ndarray:
    """Discretize a 1-D series into n_bins integer bins for MI estimation."""
    if series.size == 0:
        return series.astype(np.int64)
    edges = np.linspace(series.min() - 1e-9, series.max() + 1e-9, n_bins + 1)
    return np.clip(np.digitize(series, edges) - 1, 0, n_bins - 1)


def mutual_information(x: np.ndarray, y: np.ndarray, n_bins: int = 8) -> float:
    """Discrete mutual information I(X; Y) — Eq. (9)."""
    xb = _discretize(x, n_bins)
    yb = _discretize(y, n_bins)
    hist_xy, _, _ = np.histogram2d(xb, yb, bins=n_bins, range=[[0, n_bins], [0, n_bins]])
    pxy = hist_xy / max(hist_xy.sum(), 1.0)
    px = pxy.sum(axis=1, keepdims=True)
    py = pxy.sum(axis=0, keepdims=True)
    nz = pxy > 0
    log_ratio = np.zeros_like(pxy)
    log_ratio[nz] = np.log(pxy[nz] / (px @ py + 1e-12)[nz])
    return float(np.sum(pxy * log_ratio))


def upper_lower_coordination(keypoint_seq: np.ndarray,
                              fps: float = 60.0) -> float:
    """Compute upper-limb / lower-limb mutual-information coordination.

    The upper-limb summary signal is the average speed of all upper-limb
    keypoints; similarly for lower-limb. Mutual information is computed
    between these two scalar series, in nats.
    """
    T = keypoint_seq.shape[0]
    if T < 3:
        return 0.0
    diffs = np.diff(keypoint_seq, axis=0)                 # (T-1, 17, 2)
    speed = np.linalg.norm(diffs, axis=-1) * fps          # (T-1, 17), px/s
    upper = speed[:, UPPER_LIMB_IDX].mean(axis=1)
    lower = speed[:, LOWER_LIMB_IDX].mean(axis=1)
    return mutual_information(upper, lower, n_bins=8)


def extract_coordination_features(keypoint_seq: np.ndarray,
                                    fps: float = 60.0) -> dict:
    """Top-level convenience wrapper for coordination features (Table 3)."""
    return {
        "left_right_symmetry":    left_right_symmetry(keypoint_seq),
        "upper_lower_coordination": upper_lower_coordination(keypoint_seq, fps),
    }


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    T = 240
    seq = np.zeros((T, 17, 2))
    for j in range(17):
        sign = 1.0 if j in [5, 7, 9, 11, 13, 15] else -1.0
        seq[:, j, 0] = 100 + sign * 80 * np.sin(np.arange(T) * 0.10)
        seq[:, j, 1] = 200 + 80 * np.cos(np.arange(T) * 0.10)
    feat = extract_coordination_features(seq)
    print("Coordination features:")
    for k, v in feat.items():
        print(f"  {k}: {v:.4f}")
