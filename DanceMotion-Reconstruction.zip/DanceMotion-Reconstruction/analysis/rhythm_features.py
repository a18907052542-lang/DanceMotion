# -*- coding: utf-8 -*-
"""Rhythm feature extraction.

Implements the rhythm metrics described in Section 3.4:

    1. Beat Matching Degree R_match (Eq. 10):

           R_match = 1 − (1/N) · Σ_{n=1..N} min(|t_n^motion − t_m^beat|, τ) / τ

       where t_n^motion is the timestamp of the n-th motion rhythm anchor
       (a velocity peak in the global motion signal), t_m^beat is the
       nearest music-beat timestamp, τ is the tolerance threshold and N
       is the total number of anchors.

    2. Rhythm Stability:
           Variance of motion periods between consecutive anchors.
"""
from __future__ import annotations
import numpy as np


def detect_motion_anchors(keypoint_seq: np.ndarray,
                           fps: float = 60.0,
                           prominence: float = 0.0) -> np.ndarray:
    """Detect motion-rhythm anchor points = velocity peaks of the global motion.

    Args:
        keypoint_seq: (T, 17, 2) keypoint sequence.
        fps:          frame rate.
        prominence:   optional minimum prominence threshold for scipy.signal.find_peaks.
    Returns:
        anchor times in seconds (1-D ndarray).
    """
    from scipy.signal import find_peaks

    T = keypoint_seq.shape[0]
    if T < 5:
        return np.array([], dtype=np.float64)

    diffs = np.diff(keypoint_seq, axis=0)                            # (T-1, 17, 2)
    speed = np.linalg.norm(diffs, axis=-1).mean(axis=1) * fps        # (T-1,), px/s

    # Smooth speed with a Hann window before peak picking
    win = max(3, int(0.1 * fps) | 1)
    kernel = np.hanning(win)
    kernel = kernel / kernel.sum()
    smooth_speed = np.convolve(speed, kernel, mode="same")

    peaks, _ = find_peaks(smooth_speed, prominence=prominence or smooth_speed.std() * 0.2,
                          distance=max(2, int(fps * 0.15)))
    return peaks.astype(np.float64) / fps


def beat_matching_degree(motion_anchor_times: np.ndarray,
                          beat_times: np.ndarray,
                          tolerance: float = 0.20) -> float:
    """Beat matching degree R_match per Eq. (10).

    Args:
        motion_anchor_times: timestamps of motion anchors (seconds).
        beat_times:          timestamps of music beats (seconds).
        tolerance:           tolerance threshold τ in seconds.
    Returns:
        R_match ∈ [0, 1].
    """
    motion_anchor_times = np.asarray(motion_anchor_times, dtype=np.float64)
    beat_times          = np.asarray(beat_times,          dtype=np.float64)
    N = motion_anchor_times.size
    if N == 0 or beat_times.size == 0:
        return 0.0

    deviations = np.zeros(N, dtype=np.float64)
    for n, t_n in enumerate(motion_anchor_times):
        deviations[n] = np.min(np.abs(beat_times - t_n))
    deviations = np.minimum(deviations, tolerance)
    return float(1.0 - deviations.mean() / tolerance)


def rhythm_stability(motion_anchor_times: np.ndarray) -> float:
    """Variance of motion periods between consecutive anchors (Table 3).

    A lower value indicates more stable rhythm. The paper reports
    rhythm_stability ∈ [0, +∞).
    """
    motion_anchor_times = np.asarray(motion_anchor_times, dtype=np.float64)
    if motion_anchor_times.size < 3:
        return 0.0
    periods = np.diff(motion_anchor_times)
    return float(np.var(periods))


def extract_rhythm_features(keypoint_seq: np.ndarray,
                              beat_times: np.ndarray = None,
                              fps: float = 60.0,
                              tolerance: float = 0.20,
                              bpm: float = None) -> dict:
    """Top-level wrapper for rhythm features.

    If beat_times is None and bpm is provided, beats are generated at a
    regular cadence based on the BPM. This matches the paper's assumption
    that each dance combination has a target BPM (see Table 2 of the
    DanceMotion-2024 supplementary material).
    """
    anchors = detect_motion_anchors(keypoint_seq, fps=fps)
    if beat_times is None:
        if bpm is None:
            bpm = 100.0
        T = keypoint_seq.shape[0]
        duration = (T - 1) / fps
        period = 60.0 / bpm
        beat_times = np.arange(0.0, duration + period, period)

    return {
        "beat_matching_degree": beat_matching_degree(anchors, beat_times, tolerance),
        "rhythm_stability":     rhythm_stability(anchors),
    }


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    fps = 60.0
    T = 600
    bpm = 120.0
    period = 60.0 / bpm
    t = np.arange(T) / fps

    # Strong rhythmic motion: oscillation at the target BPM
    seq = np.zeros((T, 17, 2))
    for j in range(17):
        seq[:, j, 0] = 100 + 60 * np.sin(2 * np.pi * t / period + 0.2 * j)
        seq[:, j, 1] = 200 + 40 * np.cos(2 * np.pi * t / period + 0.2 * j)

    feat = extract_rhythm_features(seq, fps=fps, bpm=bpm)
    print("Rhythm features:")
    for k, v in feat.items():
        print(f"  {k}: {v:.4f}")
