# -*- coding: utf-8 -*-
"""Dance motion feature analysis modules (Section 3.4)."""
from .kinematic_features    import extract_kinematic_features
from .coordination_features import extract_coordination_features
from .rhythm_features       import extract_rhythm_features


def extract_all_features(keypoint_seq, fps=60.0, beat_times=None, bpm=None):
    """Aggregate all dance motion features described in Table 3."""
    feats = {}
    feats.update(extract_kinematic_features(keypoint_seq, fps=fps))
    feats.update(extract_coordination_features(keypoint_seq, fps=fps))
    feats.update(extract_rhythm_features(keypoint_seq, fps=fps,
                                          beat_times=beat_times, bpm=bpm))
    return feats


__all__ = ["extract_kinematic_features", "extract_coordination_features",
           "extract_rhythm_features", "extract_all_features"]
