# -*- coding: utf-8 -*-
"""Kinematic feature extraction.

Implements the kinematic feature family described in Section 3.4
and summarised in Table 3:

    1. Joint angular velocity (Eq. 8):
           ω_j^t = (θ_j^t − θ_j^{t-1}) / Δt
    2. Joint angular acceleration:
           α_j^t = (ω_j^t − ω_j^{t-1}) / Δt
    3. Motion amplitude:
           A_j = max_t ||p_j^t − p_j^bar||_2

The joint angle θ at a 3-joint chain (parent → joint → child) is the
articulation angle subtended at the central joint.
"""
from __future__ import annotations
import numpy as np


# Joint triplets defining articulation angles (parent_idx, joint_idx, child_idx)
# Indices follow the 17-keypoint COCO layout.
ANGLE_TRIPLETS = {
    "left_elbow":      (5, 7, 9),     # shoulder-elbow-wrist
    "right_elbow":     (6, 8, 10),
    "left_knee":       (11, 13, 15),  # hip-knee-ankle
    "right_knee":      (12, 14, 16),
    "left_shoulder":   (11, 5, 7),    # hip-shoulder-elbow (torso opening)
    "right_shoulder":  (12, 6, 8),
    "left_hip":        (5, 11, 13),
    "right_hip":       (6, 12, 14),
}


def compute_joint_angle(parent: np.ndarray, joint: np.ndarray, child: np.ndarray) -> float:
    """Angle subtended at the central joint of a parent → joint → child chain.

    Returns the angle in degrees ∈ [0, 180].
    """
    v1 = parent - joint
    v2 = child  - joint
    n1 = np.linalg.norm(v1) + 1e-9
    n2 = np.linalg.norm(v2) + 1e-9
    cos_theta = np.clip(np.dot(v1, v2) / (n1 * n2), -1.0, 1.0)
    return float(np.degrees(np.arccos(cos_theta)))


def compute_angle_sequence(keypoint_seq: np.ndarray,
                            joint_name: str = "left_elbow") -> np.ndarray:
    """Compute the angle time-series for a named joint."""
    triplet = ANGLE_TRIPLETS[joint_name]
    T = keypoint_seq.shape[0]
    angles = np.zeros(T, dtype=np.float64)
    for t in range(T):
        p = keypoint_seq[t, triplet[0]]
        c = keypoint_seq[t, triplet[1]]
        d = keypoint_seq[t, triplet[2]]
        angles[t] = compute_joint_angle(p, c, d)
    return angles


def angular_velocity_series(keypoint_seq: np.ndarray,
                             joint_name: str = "left_elbow",
                             fps: float = 60.0) -> np.ndarray:
    """Per-frame angular velocity ω_j^t (degrees / second) — Eq. (8)."""
    theta = compute_angle_sequence(keypoint_seq, joint_name)
    dt = 1.0 / fps
    return np.diff(theta) / dt


def angular_acceleration_series(keypoint_seq: np.ndarray,
                                 joint_name: str = "left_elbow",
                                 fps: float = 60.0) -> np.ndarray:
    """Per-frame angular acceleration α_j^t (degrees / second²)."""
    omega = angular_velocity_series(keypoint_seq, joint_name, fps)
    dt = 1.0 / fps
    return np.diff(omega) / dt


def average_angular_velocity(keypoint_seq: np.ndarray,
                              fps: float = 60.0) -> float:
    """Average angular velocity across all major joints — Table 12, ω̄."""
    means = []
    for jname in ANGLE_TRIPLETS:
        omega = angular_velocity_series(keypoint_seq, jname, fps)
        means.append(np.mean(np.abs(omega)))
    return float(np.mean(means))


def motion_amplitude(keypoint_seq: np.ndarray) -> float:
    """Maximum displacement of any keypoint from its temporal mean (Table 3)."""
    centred = keypoint_seq - keypoint_seq.mean(axis=0, keepdims=True)
    distances = np.linalg.norm(centred, axis=-1)   # (T, 17)
    return float(distances.max())


def acceleration_change_rate(keypoint_seq: np.ndarray,
                              fps: float = 60.0) -> float:
    """Std-dev of angular acceleration across all major joints (Table 3)."""
    stds = []
    for jname in ANGLE_TRIPLETS:
        alpha = angular_acceleration_series(keypoint_seq, jname, fps)
        stds.append(float(np.std(alpha)))
    return float(np.mean(stds))


def extract_kinematic_features(keypoint_seq: np.ndarray,
                                fps: float = 60.0) -> dict:
    """Top-level convenience wrapper aggregating all kinematic features."""
    return {
        "average_angular_velocity": average_angular_velocity(keypoint_seq, fps),
        "motion_amplitude":         motion_amplitude(keypoint_seq),
        "acceleration_change_rate": acceleration_change_rate(keypoint_seq, fps),
    }


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    T = 240
    seq = np.zeros((T, 17, 2))
    for j in range(17):
        seq[:, j, 0] = 100 + 80 * np.sin(np.arange(T) * 0.10 + 0.3 * j)
        seq[:, j, 1] = 200 + 80 * np.cos(np.arange(T) * 0.10 + 0.3 * j)
    feat = extract_kinematic_features(seq)
    print("Kinematic features:")
    for k, v in feat.items():
        print(f"  {k}: {v:.3f}")
