# -*- coding: utf-8 -*-
"""End-to-end trajectory reconstruction pipeline.

Integrates the three processing stages described in Section 3.3:
    1. Graph-constrained keypoint association  (Eq. 5)
    2. Skeletal-graph Laplacian observation refinement +
       Extended Kalman filtering                (Eq. 6-7)
    3. Cubic spline trajectory interpolation
"""
from __future__ import annotations
import numpy as np

from .graph_laplacian import GraphLaplacianRefiner
from .kalman_filter import MultiJointKalmanFilter
from .spline_interp import (upsample_trajectory,
                            smooth_trajectory_inplace,
                            measure_trajectory_jitter)


class TrajectoryReconstructor:
    """Pipeline-style trajectory reconstructor."""

    def __init__(self,
                 lambda_reg: float = 0.15,
                 dt: float = 1.0 / 60.0,
                 q_pos: float = 1e-3,
                 q_vel: float = 1e-2,
                 r_obs: float = 4.0,
                 spline_output_fps: float = 60.0,
                 num_joints: int = 17):
        self.refiner = GraphLaplacianRefiner(lambda_reg=lambda_reg, num_joints=num_joints)
        self.kalman = MultiJointKalmanFilter(num_joints=num_joints, dt=dt,
                                              q_pos=q_pos, q_vel=q_vel, r_obs=r_obs)
        self.input_fps = 1.0 / dt
        self.output_fps = spline_output_fps
        self.num_joints = num_joints

    def reset_filters(self):
        """Reset Kalman filter bank — call when starting a new clip."""
        self.kalman = MultiJointKalmanFilter(num_joints=self.num_joints,
                                              dt=1.0 / self.input_fps,
                                              q_pos=self.kalman.filters[0].Q[0, 0],
                                              q_vel=self.kalman.filters[0].Q[2, 2],
                                              r_obs=self.kalman.filters[0].R[0, 0])

    def reconstruct(self,
                    raw_sequence: np.ndarray,
                    visibility_sequence: np.ndarray = None,
                    upsample: bool = False) -> dict:
        """Run the full reconstruction pipeline on a sequence of detections.

        Args:
            raw_sequence:        (T, 17, 2) per-frame keypoint observations.
            visibility_sequence: optional (T, 17) visibility flags.
            upsample:            if True, upsample the filtered trajectory via cubic spline.
        Returns:
            dict with keys:
                "refined"    — (T, 17, 2) graph-Laplacian refined observations
                "filtered"   — (T, 17, 2) EKF-smoothed sequence
                "smoothed"   — same as filtered (or upsampled if requested)
                "jitter_raw"      — pixel jitter on the raw input
                "jitter_filtered" — pixel jitter on the filtered sequence
        """
        T = raw_sequence.shape[0]

        # Stage 1 (skipped here): the keypoint association step assumes
        # per-frame detections are already paired to the same skeleton —
        # for the single-person case this is implicit. The association
        # cost defined in keypoint_association.py is invoked at the
        # multi-person frontend.

        # Stage 2a: graph Laplacian refinement (per-frame closed-form)
        refined = np.zeros_like(raw_sequence)
        for t in range(T):
            refined[t] = self.refiner.refine(raw_sequence[t])

        # Stage 2b: Extended Kalman filter (per-joint temporal smoothing)
        self.reset_filters()
        filtered = self.kalman.filter_sequence(refined, vis_seq=visibility_sequence)

        # Stage 3: optional cubic-spline upsampling
        if upsample:
            smoothed = upsample_trajectory(filtered,
                                            input_fps=self.input_fps,
                                            output_fps=self.output_fps)
        else:
            smoothed = filtered

        return {
            "refined":  refined,
            "filtered": filtered,
            "smoothed": smoothed,
            "jitter_raw":      measure_trajectory_jitter(raw_sequence),
            "jitter_refined":  measure_trajectory_jitter(refined),
            "jitter_filtered": measure_trajectory_jitter(filtered),
        }


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    T = 60
    truth = np.zeros((T, 17, 2))
    for j in range(17):
        truth[:, j, 0] = 100 + 30 * np.sin(np.arange(T) * 0.15 + 0.4 * j)
        truth[:, j, 1] = 200 + 30 * np.cos(np.arange(T) * 0.15 + 0.4 * j)
    raw = truth + rng.normal(scale=4.0, size=truth.shape)

    rec = TrajectoryReconstructor()
    res = rec.reconstruct(raw)
    print(f"Raw jitter      : {res['jitter_raw']:.3f} px")
    print(f"Refined jitter  : {res['jitter_refined']:.3f} px")
    print(f"Filtered jitter : {res['jitter_filtered']:.3f} px")
    reduction = 100 * (1 - res["jitter_filtered"] / res["jitter_raw"])
    print(f"Total reduction : {reduction:.1f} %")
