# -*- coding: utf-8 -*-
"""Extended Kalman filter for trajectory temporal smoothing.

Implements Eq. (6)-(7) of the paper. The state vector encodes
position + velocity of a single keypoint:

    x_k = [x, y, dx, dy]^T

with constant-velocity dynamics

    x_k       = A · x_{k-1} + w_{k-1}                      (Eq. 6)
    z_k       = H · x_k     + v_k                          (Eq. 7)

A is the 4×4 state-transition matrix, H is the 2×4 observation matrix,
w_{k-1} ~ N(0, Q) is the process noise and v_k ~ N(0, R) the observation
noise.

A separate filter is maintained for each of the 17 COCO keypoints,
consistent with the per-joint trajectory processing described in
Section 3.3.
"""
from __future__ import annotations
import numpy as np


class KalmanFilter1Joint:
    """Single-joint linear Kalman filter (constant-velocity model)."""

    def __init__(self,
                 dt: float = 1.0 / 60.0,
                 q_pos: float = 1e-3,
                 q_vel: float = 1e-2,
                 r_obs: float = 4.0):
        self.dt = dt
        # State transition  A
        self.A = np.array([
            [1.0, 0.0, dt,  0.0],
            [0.0, 1.0, 0.0, dt ],
            [0.0, 0.0, 1.0, 0.0],
            [0.0, 0.0, 0.0, 1.0],
        ], dtype=np.float64)
        # Observation        H (we observe (x, y))
        self.H = np.array([
            [1.0, 0.0, 0.0, 0.0],
            [0.0, 1.0, 0.0, 0.0],
        ], dtype=np.float64)
        # Process noise      Q
        self.Q = np.diag([q_pos, q_pos, q_vel, q_vel])
        # Observation noise  R
        self.R = np.diag([r_obs, r_obs])

        # State estimate and covariance
        self.x = np.zeros((4, 1), dtype=np.float64)
        self.P = np.eye(4, dtype=np.float64) * 100.0
        self.initialized = False

    def initialize(self, observation: np.ndarray):
        """Initialize state with the first observation."""
        self.x = np.array([[observation[0]], [observation[1]], [0.0], [0.0]],
                          dtype=np.float64)
        self.P = np.eye(4, dtype=np.float64) * 10.0
        self.initialized = True

    def predict(self) -> np.ndarray:
        """Time update: x_k|k-1 = A · x_k-1|k-1."""
        self.x = self.A @ self.x
        self.P = self.A @ self.P @ self.A.T + self.Q
        return self.H @ self.x        # predicted observation (2×1)

    def update(self, z: np.ndarray) -> np.ndarray:
        """Measurement update with observation z = (x, y)."""
        if not self.initialized:
            self.initialize(z)
            return self.x[:2].flatten()

        # Innovation
        z = np.array(z, dtype=np.float64).reshape(2, 1)
        y_inn = z - self.H @ self.x
        S = self.H @ self.P @ self.H.T + self.R
        K = self.P @ self.H.T @ np.linalg.inv(S)
        self.x = self.x + K @ y_inn
        self.P = (np.eye(4) - K @ self.H) @ self.P
        return self.x[:2].flatten()

    def filter_step(self, z: np.ndarray) -> np.ndarray:
        """Convenience: predict + update in one call."""
        if not self.initialized:
            self.initialize(z)
            return self.x[:2].flatten()
        self.predict()
        return self.update(z)


class MultiJointKalmanFilter:
    """Filter bank — one EKF per COCO keypoint."""

    def __init__(self,
                 num_joints: int = 17,
                 dt: float = 1.0 / 60.0,
                 q_pos: float = 1e-3,
                 q_vel: float = 1e-2,
                 r_obs: float = 4.0):
        self.num_joints = num_joints
        self.filters = [KalmanFilter1Joint(dt=dt, q_pos=q_pos, q_vel=q_vel, r_obs=r_obs)
                        for _ in range(num_joints)]

    def filter_frame(self,
                     observations: np.ndarray,
                     visibility: np.ndarray = None) -> np.ndarray:
        """Filter one frame of (17, 2) observations.

        Args:
            observations: (17, 2) raw refined keypoint coordinates.
            visibility:   (17,) optional visibility flags. Invisible joints
                          rely entirely on the prediction step.
        Returns:
            filtered: (17, 2) temporally smoothed coordinates.
        """
        filtered = np.zeros_like(observations)
        for j in range(self.num_joints):
            if visibility is not None and visibility[j] < 0.5:
                if self.filters[j].initialized:
                    pred = self.filters[j].predict()
                    filtered[j] = pred.flatten()
                else:
                    filtered[j] = observations[j]
            else:
                filtered[j] = self.filters[j].filter_step(observations[j])
        return filtered

    def filter_sequence(self,
                        seq: np.ndarray,
                        vis_seq: np.ndarray = None) -> np.ndarray:
        """Filter a sequence of (T, 17, 2) observations."""
        T = seq.shape[0]
        out = np.zeros_like(seq)
        for t in range(T):
            vis_t = vis_seq[t] if vis_seq is not None else None
            out[t] = self.filter_frame(seq[t], vis_t)
        return out


if __name__ == "__main__":
    # Synthetic sanity test — sinusoidal trajectory + Gaussian noise
    rng = np.random.default_rng(0)
    T = 120
    t_arr = np.arange(T)
    truth = np.column_stack([100 + 30 * np.sin(t_arr * 0.1),
                              200 + 30 * np.cos(t_arr * 0.1)])
    obs = truth + rng.normal(scale=5.0, size=truth.shape)
    seq_obs = np.tile(obs[:, None, :], (1, 17, 1))

    flt = MultiJointKalmanFilter()
    smoothed = flt.filter_sequence(seq_obs)
    smooth_joint0 = smoothed[:, 0, :]
    raw_jitter   = np.linalg.norm(np.diff(obs, axis=0), axis=1).mean()
    smooth_jitter = np.linalg.norm(np.diff(smooth_joint0, axis=0), axis=1).mean()
    print(f"Raw per-frame jitter     : {raw_jitter:.3f} px")
    print(f"Filtered per-frame jitter: {smooth_jitter:.3f} px")
    print(f"Reduction                : {100 * (1 - smooth_jitter / raw_jitter):.1f} %")
