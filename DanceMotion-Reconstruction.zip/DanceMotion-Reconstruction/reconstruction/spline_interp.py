# -*- coding: utf-8 -*-
"""Cubic spline interpolation for trajectory upsampling.

The trajectory interpolation stage (Section 3.3) uses natural cubic
splines to upsample the EKF-filtered keypoint sequence to higher
temporal resolution while preserving continuity (C^2) and avoiding
the over-smoothing produced by aggressive low-pass filters.
"""
from __future__ import annotations
import numpy as np
from scipy.interpolate import CubicSpline


def upsample_trajectory(keypoint_seq: np.ndarray,
                         input_fps: float = 60.0,
                         output_fps: float = 120.0) -> np.ndarray:
    """Upsample a (T, 17, 2) trajectory using natural cubic splines.

    Args:
        keypoint_seq: filtered keypoints of shape (T, 17, 2).
        input_fps:    frame rate of the input sequence.
        output_fps:   target frame rate.
    Returns:
        upsampled trajectory of shape (T', 17, 2) where T' is determined
        by the ratio output_fps / input_fps.
    """
    T, J, D = keypoint_seq.shape
    t_in = np.arange(T) / input_fps
    duration = (T - 1) / input_fps
    n_out = int(np.floor(duration * output_fps)) + 1
    t_out = np.arange(n_out) / output_fps
    t_out = np.clip(t_out, t_in[0], t_in[-1])

    out = np.zeros((n_out, J, D), dtype=np.float64)
    for j in range(J):
        for d in range(D):
            cs = CubicSpline(t_in, keypoint_seq[:, j, d], bc_type="natural")
            out[:, j, d] = cs(t_out)
    return out


def smooth_trajectory_inplace(keypoint_seq: np.ndarray,
                                window_sec: float = 0.1,
                                input_fps: float = 60.0) -> np.ndarray:
    """Apply a short-window cubic spline smoothing without upsampling."""
    T, J, D = keypoint_seq.shape
    t_in = np.arange(T) / input_fps
    smoothed = keypoint_seq.copy()
    win = max(3, int(window_sec * input_fps) | 1)   # ensure odd
    half = win // 2
    for j in range(J):
        for d in range(D):
            y = keypoint_seq[:, j, d]
            for i in range(T):
                lo = max(0, i - half)
                hi = min(T, i + half + 1)
                xs = t_in[lo:hi]
                ys = y[lo:hi]
                if len(xs) >= 4:
                    cs = CubicSpline(xs, ys, bc_type="natural")
                    smoothed[i, j, d] = cs(t_in[i])
    return smoothed


def measure_trajectory_jitter(keypoint_seq: np.ndarray) -> float:
    """Mean per-frame displacement (pixel jitter) over the sequence.

    The paper defines trajectory jitter as the average L2 displacement
    between consecutive frames in pixels.
    """
    diffs = np.linalg.norm(np.diff(keypoint_seq, axis=0), axis=-1)   # (T-1, 17)
    return float(diffs.mean())


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    T = 60
    seq = np.zeros((T, 17, 2))
    for j in range(17):
        seq[:, j, 0] = 100 + 20 * np.sin(np.arange(T) * 0.2 + j) + rng.normal(scale=2, size=T)
        seq[:, j, 1] = 200 + 20 * np.cos(np.arange(T) * 0.2 + j) + rng.normal(scale=2, size=T)

    up = upsample_trajectory(seq, input_fps=60, output_fps=120)
    sm = smooth_trajectory_inplace(seq)
    print(f"Original sequence shape  : {seq.shape}")
    print(f"Upsampled shape          : {up.shape}")
    print(f"Jitter raw      : {measure_trajectory_jitter(seq):.3f} px")
    print(f"Jitter smoothed : {measure_trajectory_jitter(sm):.3f} px")
    print(f"Jitter upsampled: {measure_trajectory_jitter(up):.3f} px")
