# -*- coding: utf-8 -*-
"""Skeletal-graph Laplacian observation refinement.

Implements the graph regularisation step described in Section 3.3:

    P_refined^t = argmin_P  || P - P^t ||_F^2  +  λ · tr(P^T L_s P)

whose closed-form solution is

    P_refined^t = (I + λ · L_s)^{-1} · P^t                  (λ = 0.15)

The matrix (I + λ·L_s)^{-1} is pre-computed once and re-used for every
frame so the refinement adds negligible per-frame cost.

The skeletal graph G_s = (V, E_s) follows the standard 17-joint COCO
connectivity (shoulder-elbow, elbow-wrist, hip-knee, knee-ankle, ...).
"""
from __future__ import annotations
import numpy as np


# 17-keypoint COCO indices (0-based)
COCO_KEYPOINTS = [
    "nose", "left_eye", "right_eye", "left_ear", "right_ear",
    "left_shoulder", "right_shoulder",
    "left_elbow", "right_elbow",
    "left_wrist", "right_wrist",
    "left_hip", "right_hip",
    "left_knee", "right_knee",
    "left_ankle", "right_ankle",
]

# Edge set E_s (0-indexed). Includes head, torso, both arms, both legs.
SKELETAL_EDGES = [
    # Head
    (0, 1), (0, 2), (1, 3), (2, 4),
    # Torso
    (5, 6), (5, 11), (6, 12), (11, 12),
    # Left arm
    (5, 7), (7, 9),
    # Right arm
    (6, 8), (8, 10),
    # Left leg
    (11, 13), (13, 15),
    # Right leg
    (12, 14), (14, 16),
]
NUM_JOINTS = 17


def build_adjacency_matrix(num_joints: int = NUM_JOINTS,
                            edges=None) -> np.ndarray:
    """Build the symmetric adjacency matrix A_s ∈ {0,1}^{17×17}."""
    edges = edges if edges is not None else SKELETAL_EDGES
    A = np.zeros((num_joints, num_joints), dtype=np.float64)
    for i, j in edges:
        A[i, j] = 1.0
        A[j, i] = 1.0
    return A


def build_graph_laplacian(num_joints: int = NUM_JOINTS,
                           edges=None) -> np.ndarray:
    """Build the (un-normalised) graph Laplacian L_s = D_s − A_s."""
    A = build_adjacency_matrix(num_joints, edges)
    D = np.diag(A.sum(axis=1))
    L = D - A
    return L


class GraphLaplacianRefiner:
    """Closed-form per-frame skeletal graph Laplacian refinement."""

    def __init__(self,
                 lambda_reg: float = 0.15,
                 num_joints: int = NUM_JOINTS,
                 edges=None):
        self.lambda_reg = float(lambda_reg)
        self.num_joints = num_joints

        # L_s (17×17) and (I + λ L_s)^{-1} pre-computed once for runtime efficiency
        L = build_graph_laplacian(num_joints, edges)
        I = np.eye(num_joints, dtype=np.float64)
        self.L_s = L
        self.M_inv = np.linalg.inv(I + self.lambda_reg * L)

    def refine(self, P: np.ndarray) -> np.ndarray:
        """Refine raw keypoint observations using graph regularization.

        Args:
            P: (17, 2) raw keypoint coordinates for a single frame,
               or (T, 17, 2) for a sequence of T frames.
        Returns:
            P_refined: same shape as P with the closed-form smoothed coordinates.
        """
        if P.ndim == 2:
            return self.M_inv @ P
        elif P.ndim == 3:
            T = P.shape[0]
            out = np.zeros_like(P)
            for t in range(T):
                out[t] = self.M_inv @ P[t]
            return out
        else:
            raise ValueError(f"Unsupported P shape: {P.shape}")

    def refine_with_visibility(self, P: np.ndarray, vis: np.ndarray) -> np.ndarray:
        """Variant that down-weights low-visibility joints during refinement."""
        if P.ndim != 2 or vis.ndim != 1:
            raise ValueError("P must be (17,2) and vis must be (17,).")
        W = np.diag(np.clip(vis, 0.1, 1.0))
        I = np.eye(self.num_joints, dtype=np.float64)
        M_inv = np.linalg.inv(W + self.lambda_reg * self.L_s)
        return M_inv @ (W @ P)


if __name__ == "__main__":
    refiner = GraphLaplacianRefiner(lambda_reg=0.15)
    print(f"Number of skeletal edges : {len(SKELETAL_EDGES)}")
    print(f"L_s shape                : {refiner.L_s.shape}")
    print(f"(I + λL)^-1 shape        : {refiner.M_inv.shape}")
    rng = np.random.default_rng(42)
    P = rng.normal(loc=100.0, scale=20.0, size=(17, 2))
    P_refined = refiner.refine(P)
    print(f"Raw max |x|              : {np.abs(P).max():.2f}")
    print(f"Refined max |x|          : {np.abs(P_refined).max():.2f}")
    print(f"Smoothing displacement   : {np.linalg.norm(P - P_refined):.3f} px")
