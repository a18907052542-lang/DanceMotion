# -*- coding: utf-8 -*-
"""Keypoint association across consecutive frames.

Implements the matching cost function defined in Eq. (5):

    C_ij = α_1 · d_app(f_i^t, f_j^{t-1}) + α_2 · d_pos(p_i^t, p̂_j^t)

where d_app is the appearance-feature distance, d_pos is the Euclidean
distance between the current observed position and the position predicted
from the previous frame, and α_1, α_2 are tunable weights.

The optimal one-to-one assignment is solved with the Hungarian algorithm
(scipy.optimize.linear_sum_assignment).
"""
from __future__ import annotations
import numpy as np
from scipy.optimize import linear_sum_assignment


def cosine_distance(a: np.ndarray, b: np.ndarray) -> float:
    """1 − cosine-similarity between two feature vectors."""
    denom = np.linalg.norm(a) * np.linalg.norm(b) + 1e-12
    return 1.0 - float(np.dot(a, b) / denom)


def euclidean_distance(p: np.ndarray, q: np.ndarray) -> float:
    return float(np.linalg.norm(p - q))


def build_cost_matrix(features_t: np.ndarray,
                       features_prev: np.ndarray,
                       positions_t: np.ndarray,
                       positions_predicted: np.ndarray,
                       alpha_1: float = 0.4,
                       alpha_2: float = 0.6,
                       d_pos_scale: float = 50.0) -> np.ndarray:
    """Build the cost matrix C ∈ R^{N×M} per Eq. (5).

    Args:
        features_t:           (N, D) appearance features for current-frame detections.
        features_prev:        (M, D) appearance features for previous-frame tracks.
        positions_t:          (N, 2) current-frame observed positions.
        positions_predicted:  (M, 2) positions predicted from previous frame state.
        alpha_1, alpha_2:     weighting coefficients α_1, α_2.
        d_pos_scale:          pixel scale to normalise the position distance.
    Returns:
        cost: (N, M) cost matrix.
    """
    N = features_t.shape[0]
    M = features_prev.shape[0]
    cost = np.zeros((N, M), dtype=np.float64)
    for i in range(N):
        for j in range(M):
            d_app = cosine_distance(features_t[i], features_prev[j])
            d_pos = euclidean_distance(positions_t[i], positions_predicted[j]) / d_pos_scale
            cost[i, j] = alpha_1 * d_app + alpha_2 * d_pos
    return cost


def hungarian_match(cost: np.ndarray, max_cost: float = 2.5) -> list:
    """Solve the optimal assignment problem.

    Args:
        cost:     (N, M) cost matrix.
        max_cost: associations with cost above this threshold are discarded
                  (treated as new tracks / lost tracks).
    Returns:
        list of (i, j) index pairs giving the optimal assignment.
    """
    row_ind, col_ind = linear_sum_assignment(cost)
    matches = []
    for r, c in zip(row_ind, col_ind):
        if cost[r, c] <= max_cost:
            matches.append((int(r), int(c)))
    return matches


def associate_keypoints(features_t: np.ndarray,
                         features_prev: np.ndarray,
                         positions_t: np.ndarray,
                         positions_predicted: np.ndarray,
                         alpha_1: float = 0.4,
                         alpha_2: float = 0.6,
                         d_pos_scale: float = 50.0,
                         max_cost: float = 2.5) -> list:
    """End-to-end association: build cost → run Hungarian → filter."""
    cost = build_cost_matrix(features_t, features_prev, positions_t, positions_predicted,
                              alpha_1=alpha_1, alpha_2=alpha_2, d_pos_scale=d_pos_scale)
    return hungarian_match(cost, max_cost=max_cost)


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    F = 32
    feats_t = rng.normal(size=(17, F))
    feats_prev = feats_t + rng.normal(scale=0.05, size=feats_t.shape)
    pos_t = rng.normal(loc=100, scale=20, size=(17, 2))
    pos_pred = pos_t + rng.normal(scale=2, size=pos_t.shape)
    matches = associate_keypoints(feats_t, feats_prev, pos_t, pos_pred)
    correct = sum(1 for i, j in matches if i == j)
    print(f"Associated pairs : {len(matches)}/17")
    print(f"Correct matches  : {correct}/{len(matches) or 1}")
