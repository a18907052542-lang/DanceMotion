# -*- coding: utf-8 -*-
"""PyTorch dataset class for DanceMotion-2024.

Reads COCO-format annotations produced by the data construction
pipeline and emits image tensors + 64×48 ground-truth heatmaps for
training the pose estimation network.
"""
from __future__ import annotations
import os
import json
from typing import Optional, List, Dict

import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from PIL import Image


# COCO 17 keypoint configuration shared with the rest of the project
COCO_KEYPOINTS = [
    "nose", "left_eye", "right_eye", "left_ear", "right_ear",
    "left_shoulder", "right_shoulder",
    "left_elbow", "right_elbow",
    "left_wrist", "right_wrist",
    "left_hip", "right_hip",
    "left_knee", "right_knee",
    "left_ankle", "right_ankle",
]
NUM_KEYPOINTS = 17

# Horizontal-flip pairs used by the augmentation pipeline
FLIP_PAIRS = [(1, 2), (3, 4), (5, 6), (7, 8),
              (9, 10), (11, 12), (13, 14), (15, 16)]


class DanceMotionDataset(Dataset):
    """DanceMotion-2024 dataset returning images, heatmaps and metadata.

    Args:
        root:              dataset root directory.
        split:             one of {"train", "val", "test"}.
        image_size:        network input resolution (paper: 256×192).
        heatmap_size:      heatmap supervision resolution (paper: 64×48).
        sigma_h:           Gaussian standard deviation for heatmap synthesis (paper: 2 px).
        augmentation:      callable applied to image + keypoints during training.
        category_filter:   optional list to restrict the loaded categories.
    """

    def __init__(self,
                 root: str,
                 split: str = "train",
                 image_size=(256, 192),
                 heatmap_size=(64, 48),
                 sigma_h: float = 2.0,
                 augmentation=None,
                 category_filter: Optional[List[str]] = None):
        assert split in ("train", "val", "test"), f"unknown split {split}"
        self.root = root
        self.split = split
        self.image_size = image_size
        self.heatmap_size = heatmap_size
        self.sigma_h = float(sigma_h)
        self.augmentation = augmentation
        self.category_filter = set(category_filter) if category_filter else None

        coco_path = os.path.join(root, "annotations", "coco", f"{split}.json")
        with open(coco_path, "r", encoding="utf-8") as f:
            coco = json.load(f)
        img_lookup = {img["id"]: img for img in coco["images"]}

        self.samples: List[Dict] = []
        for ann in coco["annotations"]:
            img = img_lookup.get(ann["image_id"])
            if img is None:
                continue
            if self.category_filter and img.get("dance_category_en") not in self.category_filter:
                continue
            self.samples.append({
                "image_path": os.path.join(root, img["file_name"]),
                "width":      img["width"],
                "height":     img["height"],
                "session_id": img.get("session_id"),
                "dancer_id":  img.get("dancer_id"),
                "category":   img.get("dance_category"),
                "category_en": img.get("dance_category_en"),
                "combo_id":   img.get("combo_id"),
                "view":       img.get("camera_view"),
                "frame_idx":  img.get("frame_index_in_video"),
                "bbox":       ann["bbox"],
                "area":       ann.get("area", ann["bbox"][2] * ann["bbox"][3]),
                "keypoints":  np.array(ann["keypoints"], dtype=np.float32).reshape(-1, 3),
            })

    def __len__(self) -> int:
        return len(self.samples)

    def _crop_and_resize(self, img: np.ndarray, bbox: list, keypoints: np.ndarray):
        x, y, w, h = bbox
        pad_x, pad_y = int(0.1 * w), int(0.1 * h)
        x1 = max(0, int(x - pad_x))
        y1 = max(0, int(y - pad_y))
        x2 = min(img.shape[1], int(x + w + pad_x))
        y2 = min(img.shape[0], int(y + h + pad_y))
        crop = img[y1:y2, x1:x2]

        kpts = keypoints.copy()
        kpts[:, 0] -= x1
        kpts[:, 1] -= y1

        ch, cw = crop.shape[:2]
        scale_x = self.image_size[1] / cw
        scale_y = self.image_size[0] / ch
        kpts[:, 0] *= scale_x
        kpts[:, 1] *= scale_y

        resized = np.array(Image.fromarray(crop).resize(
            (self.image_size[1], self.image_size[0]), Image.BILINEAR))
        return resized, kpts

    def _generate_heatmap(self, kpts: np.ndarray):
        """2-D Gaussian heatmap with σ_h pixels at each visible keypoint."""
        H, W = self.heatmap_size
        stride_x = self.image_size[1] / W
        stride_y = self.image_size[0] / H
        target = np.zeros((NUM_KEYPOINTS, H, W), dtype=np.float32)
        weight = np.zeros((NUM_KEYPOINTS,),     dtype=np.float32)

        tmp_size = int(3 * self.sigma_h)
        ksz = 2 * tmp_size + 1
        xs, ys = np.meshgrid(np.arange(ksz), np.arange(ksz))
        gauss = np.exp(-((xs - tmp_size) ** 2 + (ys - tmp_size) ** 2) /
                       (2 * self.sigma_h ** 2)).astype(np.float32)

        for k in range(NUM_KEYPOINTS):
            v = kpts[k, 2]
            if v < 1:
                continue
            mu_x = int(kpts[k, 0] / stride_x + 0.5)
            mu_y = int(kpts[k, 1] / stride_y + 0.5)
            ul = (mu_x - tmp_size, mu_y - tmp_size)
            br = (mu_x + tmp_size + 1, mu_y + tmp_size + 1)
            if ul[0] >= W or ul[1] >= H or br[0] < 0 or br[1] < 0:
                continue
            gx = max(0, -ul[0]), min(br[0], W) - ul[0]
            gy = max(0, -ul[1]), min(br[1], H) - ul[1]
            ix = max(0, ul[0]), min(br[0], W)
            iy = max(0, ul[1]), min(br[1], H)
            target[k, iy[0]:iy[1], ix[0]:ix[1]] = gauss[gy[0]:gy[1], gx[0]:gx[1]]
            weight[k] = 1.0
        return target, weight

    def __getitem__(self, idx: int):
        s = self.samples[idx]
        img = np.array(Image.open(s["image_path"]).convert("RGB"))
        img, kpts = self._crop_and_resize(img, s["bbox"], s["keypoints"])

        if self.augmentation is not None and self.split == "train":
            result = self.augmentation(image=img, keypoints=kpts[:, :2].tolist())
            img = result["image"]
            kpts[:, :2] = np.array(result["keypoints"], dtype=np.float32)

        target, target_weight = self._generate_heatmap(kpts)

        img_tensor = torch.from_numpy(img).permute(2, 0, 1).float() / 255.0
        mean = torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1)
        std  = torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)
        img_tensor = (img_tensor - mean) / std

        meta = {
            "session_id": s["session_id"],
            "dancer_id":  s["dancer_id"],
            "category":   s["category"],
            "category_en": s["category_en"],
            "combo_id":   s["combo_id"],
            "view":       s["view"],
            "frame_idx":  s["frame_idx"],
            "bbox":       s["bbox"],
            "area":       s["area"],
        }
        return (img_tensor,
                torch.from_numpy(target),
                torch.from_numpy(target_weight),
                torch.from_numpy(kpts).float(),
                meta)


def build_dataloader(root: str, split: str = "train",
                      batch_size: int = 32,
                      num_workers: int = 8,
                      image_size=(256, 192),
                      heatmap_size=(64, 48),
                      sigma_h: float = 2.0,
                      augmentation=None,
                      shuffle: Optional[bool] = None,
                      pin_memory: bool = True) -> DataLoader:
    """Convenience wrapper for the DataLoader."""
    ds = DanceMotionDataset(root=root, split=split,
                             image_size=image_size, heatmap_size=heatmap_size,
                             sigma_h=sigma_h, augmentation=augmentation)
    if shuffle is None:
        shuffle = (split == "train")
    return DataLoader(ds, batch_size=batch_size, num_workers=num_workers,
                       shuffle=shuffle, pin_memory=pin_memory,
                       drop_last=(split == "train"),
                       collate_fn=collate_with_meta)


def collate_with_meta(batch):
    imgs    = torch.stack([b[0] for b in batch], dim=0)
    targets = torch.stack([b[1] for b in batch], dim=0)
    weights = torch.stack([b[2] for b in batch], dim=0)
    kpts    = torch.stack([b[3] for b in batch], dim=0)
    metas   = [b[4] for b in batch]
    return imgs, targets, weights, kpts, metas
