# -*- coding: utf-8 -*-
"""Data augmentation pipeline for the DanceMotion-2024 training set.

Section 4.1 of the paper describes the augmentation strategy:
    - Random horizontal flipping
    - Random rotation within ±30°
    - Random scaling 0.75 – 1.25×
    - Color jittering
    - Stage-lighting brightness gradient
    - Direction-aware motion blur on rapidly moving limb regions

After augmentation the training set expands to 4× the original size.
"""
from __future__ import annotations
import random
import numpy as np
import cv2

from .dataset import FLIP_PAIRS


class DanceAugmentation:
    """Online random-composition augmentation pipeline."""

    def __init__(self,
                 flip_p: float = 0.5,
                 rotate_p: float = 0.7, rotate_deg: float = 30.0,
                 scale_p: float = 0.7, scale_low: float = 0.75, scale_high: float = 1.25,
                 brightness_p: float = 0.8, brightness_range: float = 0.2,
                 contrast_p: float = 0.8, contrast_range: float = 0.2,
                 saturation_p: float = 0.8, saturation_range: float = 0.2,
                 hue_p: float = 0.8, hue_range: float = 0.1,
                 stage_light_p: float = 0.25, stage_light_gradient: float = 0.25,
                 motion_blur_p: float = 0.3,  motion_blur_kernel_range=(5, 15)):
        self.flip_p = flip_p
        self.rotate_p = rotate_p
        self.rotate_deg = rotate_deg
        self.scale_p = scale_p
        self.scale_low = scale_low
        self.scale_high = scale_high
        self.brightness_p = brightness_p
        self.brightness_range = brightness_range
        self.contrast_p = contrast_p
        self.contrast_range = contrast_range
        self.saturation_p = saturation_p
        self.saturation_range = saturation_range
        self.hue_p = hue_p
        self.hue_range = hue_range
        self.stage_light_p = stage_light_p
        self.stage_light_gradient = stage_light_gradient
        self.motion_blur_p = motion_blur_p
        self.motion_blur_kernel_range = motion_blur_kernel_range

    def __call__(self, image: np.ndarray, keypoints):
        keypoints = np.array(keypoints, dtype=np.float32).reshape(-1, 2)
        h, w = image.shape[:2]

        # Random horizontal flip
        if random.random() < self.flip_p:
            image = image[:, ::-1, :].copy()
            keypoints[:, 0] = (w - 1) - keypoints[:, 0]
            for l, r in FLIP_PAIRS:
                keypoints[[l, r]] = keypoints[[r, l]]

        # Random rotation
        if random.random() < self.rotate_p:
            angle = random.uniform(-self.rotate_deg, self.rotate_deg)
            M = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
            image = cv2.warpAffine(image, M, (w, h), flags=cv2.INTER_LINEAR,
                                   borderMode=cv2.BORDER_REFLECT_101)
            ones = np.ones((keypoints.shape[0], 1), dtype=np.float32)
            kpts_h = np.concatenate([keypoints, ones], axis=1)
            keypoints = (M @ kpts_h.T).T

        # Random scaling
        if random.random() < self.scale_p:
            s = random.uniform(self.scale_low, self.scale_high)
            new_w, new_h = int(w * s), int(h * s)
            image = cv2.resize(image, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
            # Center-crop or pad back to (w, h)
            if s >= 1.0:
                x0, y0 = (new_w - w) // 2, (new_h - h) // 2
                image = image[y0:y0 + h, x0:x0 + w]
                keypoints = keypoints * s
                keypoints[:, 0] -= x0
                keypoints[:, 1] -= y0
            else:
                canvas = np.zeros((h, w, image.shape[2]), dtype=image.dtype)
                x0, y0 = (w - new_w) // 2, (h - new_h) // 2
                canvas[y0:y0 + new_h, x0:x0 + new_w] = image
                image = canvas
                keypoints = keypoints * s
                keypoints[:, 0] += x0
                keypoints[:, 1] += y0

        # Color jitter (brightness / contrast / saturation / hue)
        if random.random() < self.brightness_p:
            f = 1.0 + random.uniform(-self.brightness_range, self.brightness_range)
            image = np.clip(image * f, 0, 255).astype(image.dtype)
        if random.random() < self.contrast_p:
            f = 1.0 + random.uniform(-self.contrast_range, self.contrast_range)
            mean = image.mean(axis=(0, 1), keepdims=True)
            image = np.clip((image - mean) * f + mean, 0, 255).astype(image.dtype)
        if random.random() < self.saturation_p:
            f = 1.0 + random.uniform(-self.saturation_range, self.saturation_range)
            hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV).astype(np.float32)
            hsv[:, :, 1] = np.clip(hsv[:, :, 1] * f, 0, 255)
            image = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB)
        if random.random() < self.hue_p:
            h_shift = random.uniform(-self.hue_range, self.hue_range) * 180
            hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV).astype(np.float32)
            hsv[:, :, 0] = (hsv[:, :, 0] + h_shift) % 180
            image = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB)

        # Stage lighting brightness gradient
        if random.random() < self.stage_light_p:
            grad = np.linspace(1.0 - self.stage_light_gradient,
                                1.0 + self.stage_light_gradient, num=w)
            grad = grad[None, :, None]
            image = np.clip(image * grad, 0, 255).astype(image.dtype)

        # Direction-aware motion blur along the dominant gradient direction
        if random.random() < self.motion_blur_p:
            k = random.randint(*self.motion_blur_kernel_range)
            if k % 2 == 0:
                k += 1
            angle = random.uniform(-90, 90)
            kernel = np.zeros((k, k), dtype=np.float32)
            kernel[k // 2, :] = 1.0
            M = cv2.getRotationMatrix2D((k / 2, k / 2), angle, 1.0)
            kernel = cv2.warpAffine(kernel, M, (k, k))
            kernel = kernel / max(kernel.sum(), 1e-6)
            image = cv2.filter2D(image, -1, kernel)

        return {"image": image, "keypoints": keypoints.tolist()}
