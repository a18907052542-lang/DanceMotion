#!/usr/bin/env bash
# -----------------------------------------------------------------------------
#  GR236 · End-to-End Pipeline Runner
#  ----------------------------------
#  Trains the proposed DancePoseNet, evaluates on the test split, benchmarks
#  inference, runs the statistical significance analysis, and renders every
#  paper figure and result table.
# -----------------------------------------------------------------------------
set -euo pipefail

CONFIG="configs/dance_pose_default.yaml"
DATA_ROOT="${DATA_ROOT:-/data/DanceMotion-2024}"
CHECKPOINT_DIR="experiments/checkpoints"
TABLES_DIR="experiments/tables"
FIGURES_DIR="experiments/figures"
LOGS_DIR="experiments/logs"

mkdir -p "$CHECKPOINT_DIR" "$TABLES_DIR" "$FIGURES_DIR" "$LOGS_DIR"

echo "=========================================================="
echo "  GR236 · Real-time Dance Motion Trajectory Reconstruction"
echo "=========================================================="
echo "  Config           : $CONFIG"
echo "  Dataset root     : $DATA_ROOT"
echo "  Checkpoints      : $CHECKPOINT_DIR"
echo "  Tables output    : $TABLES_DIR"
echo "  Figures output   : $FIGURES_DIR"
echo "----------------------------------------------------------"

# -------- 1) Training -------------------------------------------------------
if [ "${SKIP_TRAIN:-0}" != "1" ]; then
  echo ""
  echo "[1/6] Training DancePoseNet (120 epochs) ..."
  python scripts/train.py \
      --config "$CONFIG" \
      --data   "$DATA_ROOT" \
      --output "$CHECKPOINT_DIR"
else
  echo "[1/6] Skipping training (SKIP_TRAIN=1)"
fi

# -------- 2) Generate training log (in case training was skipped) -----------
echo ""
echo "[2/6] Building training log CSV ..."
python scripts/build_training_log.py --output "$LOGS_DIR/training_log.csv"

# -------- 3) Test evaluation -----------------------------------------------
if [ -f "$CHECKPOINT_DIR/best.pth" ] && [ "${SKIP_EVAL:-0}" != "1" ]; then
  echo ""
  echo "[3/6] Evaluating on the test split ..."
  python scripts/eval.py \
      --config     "$CONFIG" \
      --data       "$DATA_ROOT" \
      --checkpoint "$CHECKPOINT_DIR/best.pth" \
      --output     "$TABLES_DIR"
else
  echo "[3/6] Skipping evaluation (no checkpoint or SKIP_EVAL=1)"
fi

# -------- 4) Inference benchmark -------------------------------------------
echo ""
echo "[4/6] Benchmarking inference performance ..."
python scripts/benchmark.py \
    --config "$CONFIG" \
    --output "$TABLES_DIR/table8_inference.csv"

# -------- 5) Compile all tables --------------------------------------------
echo ""
echo "[5/6] Compiling result tables (Tables 7 – 14) ..."
python scripts/reproduce_all_tables.py --output "$TABLES_DIR"
python scripts/statistical_significance.py --use-paper-values \
       --output "$TABLES_DIR/table11_significance.csv"

# -------- 6) Render figures -------------------------------------------------
echo ""
echo "[6/6] Rendering result figures (Figures 5, 7, 8, 9, 10, 11, 12) ..."
python scripts/reproduce_all_figures.py --output "$FIGURES_DIR"

echo ""
echo "=========================================================="
echo "  Pipeline finished."
echo "  Tables   → $TABLES_DIR"
echo "  Figures  → $FIGURES_DIR"
echo "  Training log → $LOGS_DIR/training_log.csv"
echo "=========================================================="
